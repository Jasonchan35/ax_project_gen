from ProjectGen import BuildSettings, util, FileEntry
from collections import OrderedDict
import xml.etree.ElementTree as xmlElementTree
import uuid

bs = None

_last_gen_uuid = 1

def genUuid():
	global _last_gen_uuid
	_last_gen_uuid += 1
	return 'AEEEEEEE%0.16X' % _last_gen_uuid

main_group_uuid   			= 'B0000000B0000000B0000001'
product_group_uuid			= 'B0000000B0000000B0000002'
build_config_uuid 			= 'B0000000B0000000B0000003'
build_phase_sources_uuid	= 'B0000000B0000000B0000004'
build_phase_frameworks_uuid = 'B0000000B0000000B0000005'
build_phase_headers_uuid 	= 'B0000000B0000000B0000006'

def writeObj(o, obj):
	t = type(obj)
	if t is str:
		o.write(obj)
		return

	if t is list:
		o.write('(')
		o.newline(1)
		i = 0
		for p in obj:
			writeObj(o, p)
			o.writeln(',')
			i += 1
		o.newline(-1)
		o.write(')')
		return

	if t is dict:
		raise Exception('please use OrderedDict to keep output file the same')

	if t is OrderedDict:
		o.addIndent()
		o.write('{')
		for k, v in obj.items():
			o.newline()
			o.write(k + ' = ')
			writeObj(o, v)
			o.write(';')

		o.subIndent()
		o.newline()
		o.writeln('};')
		return

	raise Exception('Error writeObj unknown type ' + str(type(obj)) + 'value=' + str(obj) )

def quote_str2(s):
	return '"\\\"' + s + '\\\""'

def quote_str(s):
	return '"' + s.replace('\"', '\\\"') + '"'
		
def create_xcode_file_node(fileEntry):
	e = fileEntry
	f = e.filename
	project = e.project

	# already got this file node
	if f in project.xcode_file_nodes:
		return project.xcode_file_nodes[f]

	e.uuid = None
	e.build_uuid = None
	e.relPath = util.relFilePath(f, project.bs.outdir)
	e.virPath = util.relFilePath(f, project.build_file_dir)	
	e.children = OrderedDict()

	project.xcode_file_nodes[f] = e
	# directory
	parent_dir = util.dirname(f)

	# limited with in bs.outdir folder
	if not (parent_dir.startswith(project.build_file_dir) or parent_dir.startswith(bs.outdir)):
		return e

	parentEntry = FileEntry.FileEntry(project, parent_dir)
	parent_node = create_xcode_file_node(parentEntry)
	# same node
	if parent_node is e:
		return e

	parent_node.children[f] = e
	return e

def gen_project_PBXBuildFile(o, project):
	o.newline()

	project.xcode_file_nodes = OrderedDict()

	# main group node
	main_group_node = create_xcode_file_node(FileEntry.FileEntry(project, bs.outdir))
	main_group_node.uuid = main_group_uuid
	project.xcode_file_nodes[main_group_node.filename] = main_group_node

	# add generatd dir node
	generated_file_ndoe = create_xcode_file_node(FileEntry.FileEntry(project, bs.outdir + "_generated_"))
	main_group_node.children[generated_file_ndoe.filename] = generated_file_ndoe

	# create file_nodes
	for e in project.generatedUniteFileEntries:
		create_xcode_file_node(e)

	for e in project.fileEntries:
		create_xcode_file_node(e)

	# gen uuid
	cache_file_uuid = OrderedDict()
	cache_file_build_uuid= OrderedDict()

	for k, e in project.xcode_file_nodes.items():
		if e.virPath == '.':
			main_group_node.children[e.filename] = e			

		if e is main_group_node:
			continue

		#-- uuid 
		if not k in cache_file_uuid:
			cache_file_uuid[k] = genUuid()
		e.uuid = cache_file_uuid[k]

		#-- build uuid
		if not k in cache_file_build_uuid:
			cache_file_build_uuid[k] = genUuid()
		e.build_uuid = cache_file_build_uuid[k]

	if main_group_node is None:
		raise Exception("Cannot find virtual path root")

	# ------ gen -----------
	if True:
		o.newline()
		o.writeln('/*----- PBXFileReference -----------------*/')

		#----  target product file -----
		if True:
			o.writeln("/* target product file */ ")
			o.write( project._target_product_uuid + ' = ')

			if project.type == "cpp_exe":
				explicitFileType = "compiled.mach-o.executable"
			elif project.type == "cpp_lib":
				explicitFileType = "archive.ar"

			attrib = OrderedDict([
				("isa", "PBXFileReference"),
				("explicitFileType", explicitFileType),
				("path", quote_str(project.output_target)),
				("sourceTree", 'BUILT_PRODUCTS_DIR'),
			])
			writeObj(o, attrib)
			o.writeln('')

		o.writeln("/* ===== project dependencies ==== */ ")
		o.writeln('')
		for dep_proj in project.dependencies.values():
			o.writeln("/* " + dep_proj.name + " project dependencies ==== */ ")
			if True:
				o.writeln('/* PBXContainerItemProxy for xcodeproject */')
				dep_proj.xcode_dep_proxy_uuid = genUuid()
				o.write(dep_proj.xcode_dep_proxy_uuid + ' = ')
				attrib = OrderedDict([
					('isa', 'PBXContainerItemProxy'),
					('containerPortal', dep_proj._uuid),
					('proxyType', "2"),
					('remoteInfo', quote_str(dep_proj.name))
				])
				writeObj(o, attrib)
				o.writeln('')

				o.writeln('/* PBXContainerItemProxy for PBXTargetDependency */')
				dep_proj.xcode_dep_target_proxy_uuid = genUuid()
				o.write(dep_proj.xcode_dep_target_proxy_uuid + ' = ')
				attrib = OrderedDict([
					('isa', 'PBXContainerItemProxy'),
					('containerPortal', dep_proj._uuid),
					('proxyType', "1"),
					('remoteInfo', quote_str(dep_proj.name))
				])
				writeObj(o, attrib)
				o.writeln('')

				o.writeln('/* PBXTargetDependency */')
				dep_proj.xcode_dep_target_uuid = genUuid()
				o.write(dep_proj.xcode_dep_target_uuid + ' = ')
				attrib = OrderedDict([
					('isa', 'PBXTargetDependency'),
					('name', dep_proj.name),
					('targetProxy', dep_proj.xcode_dep_target_proxy_uuid),
				])
				writeObj(o, attrib)
				o.writeln('')

			if True:
				#--- Dep project file reference ---
				o.writeln('/* ' + dep_proj.name + '.xcodeproj */ ')
				o.write( dep_proj._uuid + ' = ' )
				attrib = OrderedDict([
					("isa", "PBXFileReference"),
					("name", quote_str(dep_proj.name)),
				 	("path", quote_str(util.relFilePath(dep_proj._xcodeproj, project.build_file_dir) )),
					("explicitFileType", quote_str('wrapper.pb-project')),
					("sourceTree", '"<group>"'),
				])
				writeObj(o, attrib)
				o.writeln('')

		o.writeln('/* ----- File Reference  --- */')
		o.writeln('')
		for k, f in project.xcode_file_nodes.items():
			if f.isDir:
				continue

			o.writeln('/* FileRef: ' + f.relPath + ' */')
			o.write( f.uuid + ' = ' )
			attrib = OrderedDict([
				("isa", "PBXFileReference"),
				("name", quote_str(f.basename)),
				("path", quote_str(f.basename)),
				("sourceTree", '"<group>"'),
			])

			explicitFileType = None
			if f.type == ".cpp":
				if bs.cpp_objcpp:
					explicitFileType = "sourcecode.cpp.objcpp"
				else:
					explicitFileType = "sourcecode.cpp.cpp"

			if f.type == ".h":
				explicitFileType = "sourcecode.cpp.h"

			if not explicitFileType is None:
				attrib['explicitFileType'] = explicitFileType

			writeObj(o, attrib)
			o.writeln('')

			#--- build file ---
			if f.buildNeeded:
				o.writeln('/* BuildFile: ' + f.relPath + ' */')
				o.write( f.build_uuid + ' = ' )
				attrib = OrderedDict([
					("isa", "PBXBuildFile"),
					("fileRef", f.uuid),
				])
				writeObj(o, attrib)
				o.writeln('')

		o.writeln('/*----- End of PBXFileReference -----------------*/')

	if True:
		o.newline()
		o.writeln('/*----- PBXFrameworksBuildPhase -----------------*/')
		#--- product_group
		o.writeln('/* Product Group */')
		o.write( build_phase_frameworks_uuid + ' = ' )
		attrib = OrderedDict([
			("isa", "PBXFrameworksBuildPhase"),
			("file", []),
			("runOnlyForDeploymentPostprocessing", '0'),
		])
		writeObj(o, attrib)
		o.writeln('')
		#-------


	if True:
		o.newline()
		o.writeln('/*----- PBXGroup -----------------*/')

		#--- product_group
		o.writeln('/* Product Group */')
		o.write( product_group_uuid + ' = ' )
		attrib = OrderedDict([
			("isa", "PBXGroup"),
			("children", [ project._target_product_uuid + ' /* ' + project.output_target + ' */']),
			("sourceTree", '"<group>"'),
			("name", "Products")
		])
		writeObj(o, attrib)
		o.writeln('')
		#-------
		for k, f in project.xcode_file_nodes.items():
			if not f.isDir:
				continue

			o.writeln('/* ' + f.filename + ' */')
			o.write( f.uuid + ' = ' )

			attrib = OrderedDict([
				("isa", "PBXGroup"),
				("children", [ c.uuid + ' /* ' + c.basename + ' */ ' for k, c in f.children.items() ]),
				("sourceTree", '"<group>"'),
			])

			if len(f.virPath) > 0:
				attrib["name"] = quote_str(f.basename)
				attrib["path"] = quote_str(f.basename)

			# virtual path root
			if f.virPath == '.':
				attrib['children'].append(product_group_uuid + ' /* Product Group */')

				for dep_proj in project.dependencies.values():
					attrib['children'].append(dep_proj._uuid + ' /* ' + dep_proj._xcodeproj + ' */')

				attrib['sourceTree'] = "SOURCE_ROOT"
				attrib["path"] = quote_str(f.relPath) # using relative path to project

			writeObj(o, attrib)
			o.writeln('')

		o.writeln('/*----- End of PBXGroup -----------------*/')

def gen_project_PBXProject(o, project):
	o.newline()
	o.writeln('/*----- PBXProject -----------------*/')
	o.write('' + project._uuid + ' /* Project object */ = {')
	o.newline(1)
	if True:
		o.writeln('isa = PBXProject;')
		o.write('attributes = {')
		o.newline(1)
		if True:
			o.writeln('LastUpgradeCheck = 0730;')
			#o.writeln('ORGANIZATIONNAME = My Name')
			o.writeln('')
			o.write('TargetAttributes = {')
			o.newline(1)
			if True:
				o.write( project._target_uuid + ' = {')
				o.newline(1)
				if True:
					o.writeln('CreatedOnToolsVersion = 7.3.1;')
				#---------
				o.newline(-1)
				o.writeln('};')
			#---------
			o.newline(-1)
			o.writeln('}; /* TargetAttributes */ ')
		#---------
		o.newline(-1)
		o.writeln('}; /* attributes */')
		o.writeln('')

		o.writeln('compatibilityVersion = "Xcode 3.2";')
		o.writeln('developmentRegion = English;')
		o.writeln('hasScannedForEncodings = 0;')
		o.writeln('knownRegions = (en,);')
		o.writeln('buildConfigurationList = ' + build_config_uuid + ';')
		o.writeln('mainGroup = ' + main_group_uuid + ';')
		o.writeln('productRefGroup = ' + product_group_uuid + ' /* Products */;')
		o.writeln('projectDirPath = "";')
		o.writeln('')
		o.write('projectReferences = ({')
		o.newline(1)
		if True:
			pass
			#o.writeln('ProductGroup = 96CB2AD41D683BBE00C34887 /* Products */;')
			#o.writeln('ProjectRef = 96CB2AD31D683BBE00C34887 /* ax_core.xcodeproj */;')
		#--------
		o.newline(-1)
		o.writeln('},); /* projectReferences */')

		o.writeln('projectRoot = "";')
		o.writeln('targets = (' + project._target_uuid + ',);')
	#---------
	o.newline(-1)
	o.writeln('}; /* project object */')
	o.writeln('/*----- End of PBXProject -----------------*/')
	o.newline()

def gen_project_PBXNativeTarget(o, project):
	o.newline()
	o.writeln('/*----- PBXNativeTarget -----------------*/')

	if project.type == "cpp_lib":
		productType = "com.apple.product-type.library.static"
	elif project.type == "cpp_exe":
		if project.gui_app or bs.os == 'ios': # iOS doesn't have command line tools
			productType = "com.apple.product-type.application"
		else:
			productType = "com.apple.product-type.tool"
	else:
		raise Exception('Unsupport project.type "' + project.type + '"')


	o.write('' + project._target_uuid + ' = ')
	attrib = OrderedDict([
		("isa", "PBXNativeTarget"),
		("buildConfigurationList", project._config_list_uuid),
		("buildPhases", [
			build_phase_sources_uuid    + " /* Sources */",
			build_phase_frameworks_uuid + " /* Frameworks */",
			build_phase_headers_uuid    + " /* Headers */"
		]),
		("buildRules", []),
		("name", quote_str(project.name)),
		("productName", quote_str(project.name)),
		("productReference", project._target_product_uuid),
		("productType", productType)
	])

	if project.type == 'cpp_exe' or project.type == 'cpp_dll':
		if len(project.dependencies) > 0:
			attrib["dependencies"] = [ (dp.xcode_dep_target_uuid + ' /* ' + dp.name + ' */') for dp in project.dependencies.values() ]
	writeObj(o, attrib)

	o.writeln('/*----- End of PBXNativeTarget -----------------*/')
	o.newline()

def gen_project_PBXSourcesBuildPhase(o, project):
	o.newline()
	o.writeln('/*----- PBXSourcesBuildPhase -----------------*/')

	o.writeln('/* build_phase_sources_uuid */')
	o.write( build_phase_sources_uuid + " = " )

	file_to_build = []
	for f in project.xcode_file_nodes.values():
		if f.buildNeeded:
			file_to_build.append( f.build_uuid + ' /* ' + f.basename + ' */' )

	attrib = OrderedDict([
		("isa", "PBXSourcesBuildPhase"),
		("buildActionMask", "2147483647"),
		("runOnlyForDeploymentPostprocessing", "0"),
		("files", file_to_build),
	])
	writeObj(o, attrib)

	o.writeln('/*----- End of PBXSourcesBuildPhase -----------------*/')
	o.newline()

def gen_project_XCBuildConfiguration(o, project):
	o.newline()
	o.writeln('/*----- XCBuildConfiguration -----------------*/')

	# Project Config
	if True:
		for config_name, config in project.configs.items():
			o.writeln('')
			o.writeln('/* Project Config ' + config_name + ' */')
			o.write(config._project_config_uuid + ' /* ' + config_name + ' */ = {')
			o.newline(1)
			if True:
				o.writeln('isa = XCBuildConfiguration;')
				#o.writeln('baseConfigurationReference = ' + config._xcconfig_uuid + ';')
				o.write('buildSettings = {')
				o.newline(1)
				if True:
					pass #TODO
				#--------
				o.newline(-1)
				o.writeln('};')
				o.writeln('name = ' + config_name + ';')

			#--------
			o.newline(-1)
			o.writeln('}; /* ' + config_name + ' */')

	# Target Config
	if True:
		for config_name, config in project.configs.items():
			o.writeln('')
			o.writeln('/* Target Config ' + config_name + ' */')
			o.write(config._target_config_uuid + ' /* ' + config_name + ' */ = {')
			o.newline(1)


			if True:
				o.writeln('isa = XCBuildConfiguration;')
				#o.writeln('baseConfigurationReference = ' + config._xcconfig_uuid + ';')
				o.write('buildSettings = ')

				link_flags = [quote_str(x) for x in config.link_flags.final]
				link_flags.extend([quote_str2(f) for f in config.link_files.final])

				attrib = OrderedDict()
				attrib['PRODUCT_NAME']					= quote_str( util.basename(config.output_target, False) )
				attrib['EXECUTABLE_PREFIX']				= quote_str("")

				#--- EXECUTABLE_EXTENSION
				targetExt = util.fileExt(config.output_target)
				if len(targetExt) > 0 and targetExt[0] == '.':
					targetExt = targetExt[1:]
				elif project.type != "cpp_exe": # no extension is needed for cpp_exe
					raise Exception('output_target missing filename extension, output_target=' + config.output_target )
				attrib['EXECUTABLE_EXTENSION']			= quote_str(targetExt)

				attrib['CONFIGURATION_BUILD_DIR']		= quote_str( util.dirname(config.output_target) )
				attrib['CONFIGURATION_TEMP_DIR']		= quote_str( bs.outdir + "_build_tmp/" + project.name + '/' + config.name )

				attrib['STRIP_STYLE']					= quote_str("all") # non-global, #debugging
				attrib['DEAD_CODE_STRIPPING']			= "YES"

				if bs.os == 'ios':
					attrib['SDKROOT']						= quote_str("iphoneos")
					attrib['SUPPORTED_PLATFORMS']			= quote_str("iphonesimulator iphoneos")			
					attrib['VALID_ARCHS']					= quote_str('arm64 armv7 armv7s')
					attrib['IPHONEOS_DEPLOYMENT_TARGET']	= quote_str('10.1')

				elif bs.os == 'macosx':
					attrib['SDKROOT']						= quote_str("macosx")
					attrib['SUPPORTED_PLATFORMS']			= quote_str("macosx")				
					attrib['MACOSX_DEPLOYMENT_TARGET']		= quote_str("10.11")
				else:
					raise Exception('Unsupport os = ' + bs.os)

				attrib['CLANG_CXX_LANGUAGE_STANDARD']	= quote_str("c++11")
				attrib['GCC_SYMBOLS_PRIVATE_EXTERN']	= "YES"

				if (config.name == "Debug"):
					attrib['DEBUG_INFORMATION_FORMAT']			= "dwarf"
					attrib['GCC_GENERATE_DEBUGGING_SYMBOLS']	= "YES"
					attrib['GCC_OPTIMIZATION_LEVEL']			= "0" #0: None[-O0], 1: Fast[-O1],  2: Faster[-O2], 3: Fastest[-O3], s: Fastest, Smallest[-Os], Fastest, Aggressive Optimizations [-Ofast]
					attrib['ONLY_ACTIVE_ARCH']					= "YES"
					attrib['ENABLE_TESTABILITY']				= "YES"

				else:
					attrib['DEBUG_INFORMATION_FORMAT']			= "dwarf-with-dsym"
					attrib['GCC_GENERATE_DEBUGGING_SYMBOLS']	= "NO"
					attrib['GCC_OPTIMIZATION_LEVEL']			= "s"

				attrib['CLANG_ENABLE_OBJC_ARC']			= "YES"

				attrib['HEADER_SEARCH_PATHS']			= [quote_str2(f) for f in config.include_dirs.final]
				attrib['OTHER_LDFLAGS']					= link_flags
				attrib['GCC_PREPROCESSOR_DEFINITIONS']	= [quote_str(x) for x in config.cpp_defines.final]
				attrib['OTHER_CPLUSPLUSFLAGS']			= [quote_str(x) for x in config.cpp_flags.final]

				'''
				attrib['DEPLOYMENT_LOCATION']			= "YES"
				attrib['DSTROOT']						= quote_str('')
				attrib['INSTALL_PATH']					= quote_str( util.dirname(util.relFilePath(config.output_target, bs.outdir)) )
				'''

				if project.type == "cpp_exe" or project.type == "cpp_dll":
					if project.gui_app:
						attrib['PRODUCT_BUNDLE_IDENTIFIER'] =	quote_str(project.xcode_bundle_identifier)
						attrib['INFOPLIST_FILE']			=	quote_str(project.xcode_info_plist_file)

				if project.pch_header:
					attrib['GCC_PRECOMPILE_PREFIX_HEADER'] = quote_str("YES")
					attrib['GCC_PREFIX_HEADER'] = quote_str(util.addBaseDir(project.pch_header, project.build_file_dir))

				for k, v in config.xcode_settings.items():
					attrib[k] = quote_str(v)

				writeObj(o, attrib)
				#--------
				o.writeln('name = ' + quote_str(config_name) + ';')

			#--------
			o.newline(-1)
			o.writeln('}; /* ' + config_name + ' */')


	o.writeln('/*----- End of XCBuildConfiguration -----------------*/')
	o.newline()

def gen_project_XCConfigurationList(o, project):
	o.newline()
	o.writeln('/*----- XCConfigurationList -----------------*/')

	if True:
		o.write(build_config_uuid + ' /* Build configuration list for PBXProject */ = {')
		o.newline(1)
		if True:
			o.writeln('isa = XCConfigurationList;')

			default_config_name = ""
			if True:
				o.write('buildConfigurations = (')
				o.newline(1)				
				for config_name, config in project.configs.items():
					o.writeln(config._project_config_uuid + ' /* '+ config_name +' */,')
					default_config_name = config_name # using last one as default
				#----------
				o.newline(-1)
				o.writeln(');')

			o.writeln('defaultConfigurationIsVisible = 0;')
			o.writeln('defaultConfigurationName = ' + quote_str(default_config_name) + ';')
		#----------
		o.newline(-1)
		o.writeln('};')

	#--------------------------
	if True:
		o.write(project._config_list_uuid + ' /* Build configuration list for PBXNativeTarget */ = {')
		o.newline(1)
		if True:
			o.writeln('isa = XCConfigurationList;')
			if True:
				o.write('buildConfigurations = (')
				o.newline(1)
				for config_name, config in project.configs.items():
					o.writeln(config._target_config_uuid + ' /* '+ config_name +' */,')
				#----------
				o.newline(-1)
				o.writeln(');')

			o.writeln('defaultConfigurationIsVisible = 0;')
			o.writeln('defaultConfigurationName = ' + config_name + ';')

		#----------
		o.newline(-1)
		o.writeln('};')

	o.writeln('/*----- End of XCConfigurationList -----------------*/')
	o.newline()

def gen_info_plist(project):
	filename = bs.outdir + project.xcode_info_plist_file
	node_root = xmlElementTree.Element("plist", attrib={"version":"1.0"})	
	doctype = {
		'name':'plist', 
		'publicId':'-//Apple//DTD PLIST 1.0//EN',
		'systemId':'http://www.apple.com/DTDs/PropertyList-1.0.dtd'}

	node_dict = xmlElementTree.SubElement(node_root, "dict")

	attrib = OrderedDict([	('CFBundleDevelopmentRegion', 'en'),
							('CFBundleExecutable', '$(EXECUTABLE_NAME)'),
							('CFBundleIconFile', ''),
							('CFBundleIdentifier', project.xcode_bundle_identifier),  #'$(PRODUCT_BUNDLE_IDENTIFIER)'
							('CFBundleInfoDictionaryVersion', '6.0'),
							('CFBundleName', '$(PRODUCT_NAME)'),
							('CFBundlePackageType','APPL'),
							('CFBundleShortVersionString','1.0'),
							('CFBundleVersion', '1'),
							('LSMinimumSystemVersion', '$(MACOSX_DEPLOYMENT_TARGET)'),
							('NSHumanReadableCopyright',''), 
							('NSMainNibFile', 'MainMenu'),
							('NSPrincipalClass', 'NSApplication')])
	for k, v in attrib.items():
		xmlElementTree.SubElement(node_dict, 'key').text = k
		t = type(v)
		if t is str:
			xmlElementTree.SubElement(node_dict, 'string').text = v
		else:
			raise Exception('unsupport type for plist value')

	util.writeXmlFile(filename, node_root, doctype)


def gen_project(project):
	util.log("gen_project " + project.name)

	if project.gui_app:
		gen_info_plist(project)

	filename = project._xcodeproj + "/project.pbxproj"
	o = util.OutBuffer()

	o.writeln('// !$*UTF8*$!')
	o.write("{")
	o.newline(1)
	if True:
		o.writeln("archiveVersion = 1;")
		o.write("classes = {")
		o.newline(1)
		if True:
			pass
		o.newline(-1)
		o.writeln("};")
		o.writeln('')

		o.writeln('objectVersion = 46;')
		o.write('objects = {')
		o.newline(1)

		if True:
			gen_project_PBXBuildFile(o, project)
			gen_project_PBXProject(o, project)
			gen_project_PBXSourcesBuildPhase(o, project)
			gen_project_PBXNativeTarget(o, project)
			gen_project_XCBuildConfiguration(o, project)
			gen_project_XCConfigurationList(o, project)

		o.newline(-1)
		o.writeln('}; /* objects */')

		o.writeln('rootObject = ' + project._uuid + ' /* Project object */;')

	o.newline(-1)
	o.writeln("}") #----- end

	util.writeFile(filename, o.getValue())

def gen_workspace():
	workspace_name = bs.workspace_name
	util.log("gen_workspace " + workspace_name)
	filename = bs.outdir + "/" + workspace_name + ".xcworkspace/contents.xcworkspacedata"

	attrib = OrderedDict([
		("version", "1.0")
	])
	node_workspace = xmlElementTree.Element("Workspace", attrib)

	for project in bs.projects.values():
		gen_project(project)
		attrib = OrderedDict([
			("location", "container:" + util.relFilePath( project._xcodeproj, bs.outdir))
		])
		xmlElementTree.SubElement(node_workspace, "FileRef", attrib)

	util.writeXmlFile(filename, node_workspace)

def openIde():
	workspace_name = bs.workspace_name # + "_" + bs.platform
	filename = bs.outdir + workspace_name + ".xcworkspace"
	print("open xcode workspace: " + filename)
	util.shell_run('open ' + filename)

def generate():
	for project in bs.projects.values():
		project._xcodeproj = bs.outdir + project.name + ".xcodeproj"
		project._uuid = genUuid()
		project._target_uuid = genUuid()
		project._target_product_uuid = genUuid()
		project._config_list_uuid = genUuid()

		for config in project.configs.values():
			config._project_config_uuid = genUuid()
			config._target_config_uuid = genUuid()
			config._target_uuid = genUuid()

#		project.fileList = project.getFiles()
#		for file_name, f in project.fileList:


	gen_workspace()

def init(buildSettings):
	global bs
	bs = buildSettings
	bs.generator = "xcode"

	if bs.compiler is None:
		bs.compiler = "clang"
