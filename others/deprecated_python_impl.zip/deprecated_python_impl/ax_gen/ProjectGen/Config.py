from ProjectGen import util
from collections import OrderedDict

class ConfigListItem:
	def __init__(self, name, isFilePath = False):
		self.name = name
		self.isFilePath = isFilePath
		self.inherit  = OrderedDict()
		self.normal   = OrderedDict()
		self.remove   = OrderedDict()
		self.local    = OrderedDict()
		self.final    = OrderedDict()
		self.export   = OrderedDict()

	def readMember(self, reader, memberName, build_file_dir):
		if not memberName.startswith(self.name):
			return False
		if memberName == self.name:
			self._readMember(reader, self.normal, build_file_dir)
			return True
		if memberName == self.name + ".remove":
			self._readMember(reader, self.remove, build_file_dir)
			return True
		if memberName == self.name + ".local":
			self._readMember(reader, self.local, build_file_dir)
			return True
		if memberName == self.name + ".export":
			self._readMember(reader, self.export, build_file_dir)
			return True

	def _readMember(self, reader, item, build_file_dir):
		arr = reader.getStringArray()
		if self.isFilePath:
			arr = util.addBaseDir(arr, build_file_dir)
		util.dictAdd(item, arr)

	def resolve(self):
		util.dictAdd(self.final, self.inherit)
		util.dictAdd(self.final, self.normal)
		util.dictAdd(self.final, self.local)

	def carryConfig(self, r):
		util.dictAdd(self.inherit,  r.inherit)
		util.dictAdd(self.inherit,  r.normal)
		util.dictAdd(self.inherit,  r.export)
		
	def dump(self, newline=False, indent=0):
		if len(self.normal):
			util.log("  {:22} = {}".format(self.name,              util.toStr(self.normal.keys(),  newline, indent)))
		if len(self.inherit):
			util.log("  {:22} = {}".format(self.name + ".inherit", util.toStr(self.inherit.keys(), newline, indent)))
		if len(self.remove):
			util.log("  {:22} = {}".format(self.name + ".remove",  util.toStr(self.remove.keys(),  newline, indent)))
		if len(self.local):
			util.log("  {:22} = {}".format(self.name + ".local",   util.toStr(self.local.keys(),   newline, indent)))
		if len(self.final):
			util.log("  {:22} = {}".format(self.name + ".final",   util.toStr(self.final.keys(),   newline, indent)))
		if len(self.export):
			util.log("  {:22} = {}".format(self.name + ".export",  util.toStr(self.export.keys(),  newline, indent)))

class Config:
	def __init__(self, buildSettings, project, name):
		self.bs = buildSettings
		self.project = project
		self.name = name
		self.cpp_defines 		= ConfigListItem("cpp_defines")
		self.cpp_flags 			= ConfigListItem("cpp_flags")
		self.include_dirs 		= ConfigListItem("include_dirs", True)
		self.link_dirs 			= ConfigListItem("link_dirs", True)
		self.link_files 		= ConfigListItem("link_files", True)
		self.link_flags 		= ConfigListItem("link_flags")
		self.disable_warning 	= ConfigListItem("disable_warning")
		self.xcode_settings 	= OrderedDict()

		self.warning_as_error = None
		self.warning_level = None

		self.output_dir = ""
		self.output_target = ""

	def resolve(self):
		self.cpp_defines.resolve()
		self.cpp_flags.resolve()
		self.include_dirs.resolve()
		self.link_dirs.resolve()
		self.link_files.resolve()
		self.link_flags.resolve()
		self.disable_warning.resolve()

		self._add_build_cpp_defines("ax_GEN_CPU"			, self.bs.cpu 		)
		self._add_build_cpp_defines("ax_GEN_OS" 			, self.bs.os 		)
		self._add_build_cpp_defines("ax_GEN_GENERATOR" 	, self.bs.generator	)
		self._add_build_cpp_defines("ax_GEN_COMPILER"		, self.bs.compiler 	)
		self._add_build_cpp_defines("ax_GEN_PROJECT" 		, self.project.name	)
		self._add_build_cpp_defines("ax_GEN_CONFIG"  		, self.name 		)
		self._add_build_cpp_defines("ax_GEN_TYPE" 		, self.project.type	)
		util.dictAdd(self.cpp_defines.final, 'ax_GEN_PLATFORM_NAME="{}"'.format(self.bs.platform))
		
	def _add_build_cpp_defines(self, m, v):
		util.dictAdd(self.cpp_defines.final, '{}_{}=1'.format(m, v))
		util.dictAdd(self.cpp_defines.final, '{}_NAME="{}"'.format(m, v))

	def carryConfig(self, another_config):
		self.cpp_defines.carryConfig( 		another_config.cpp_defines 		)
		self.cpp_flags.carryConfig(   		another_config.cpp_flags   		)
		self.include_dirs.carryConfig(		another_config.include_dirs		)
		self.link_dirs.carryConfig(			another_config.link_dirs   		)
		self.link_files.carryConfig(		another_config.link_files  		)
		self.link_flags.carryConfig(		another_config.link_flags  		)
		self.disable_warning.carryConfig( 	another_config.disable_warning	)

		if self.warning_as_error is None:
			self.warning_as_error = another_config.warning_as_error
		if self.warning_level is None:
			self.warning_level = another_config.warning_level

		for k, v in another_config.xcode_settings.items():
			self.xcode_settings[k] = v

	'''
	def _readJsonDeep(self, reader, build_file_dir):
		if not reader.beginObject():
			reader.error('{ expected')
		while not reader.endObject():
			memberName = reader.getMemberName()
			if not self.readJson(reader, memberName, build_file_dir):
				reader.error("Unknown option " + memberName)
				reader.skipValue()
	'''				

	def readJson(self, reader, build_file_dir):
		if not reader.beginObject():
			reader.error('project must starts with {')

		while not reader.endObject():		
			memberName = reader.getMemberName()
			cond_config = util.getStringFromPrefix(memberName, "config==")
			if len(cond_config) > 0:
				if cond_config == self.name:
					self.readJson(reader, build_file_dir)
				else:
					reader.skipValue()
				continue

			cond_compiler = util.getStringFromPrefix(memberName,"compiler==")
			if len(cond_compiler) > 0:
				if cond_compiler == self.bs.compiler:
					self.readJson(reader, build_file_dir)
				else:
					reader.skipValue()
				continue

			cond_generator = util.getStringFromPrefix(memberName,"generator==")
			if len(cond_generator) > 0:
				if cond_generator == self.bs.generator:
					self.readJson(reader, build_file_dir)
				else:
					reader.skipValue()
				continue

			cond_os = util.getStringFromPrefix(memberName,"os==")
			if len(cond_os) > 0:
				if cond_os == self.bs.os:
					self.readJson(reader, build_file_dir)
				else:
					reader.skipValue()
				continue
			#-------------------------
				continue
			if memberName == 'output_dir':
				self.output_dir = reader.getString()
				continue
			#-------------------------
			if self.cpp_defines.readMember(reader, memberName, build_file_dir):
				continue
			if self.cpp_flags.readMember(reader, memberName, build_file_dir):
				continue
			if self.include_dirs.readMember(reader, memberName, build_file_dir):
				continue
			if self.link_dirs.readMember(reader, memberName, build_file_dir):
				continue
			if self.link_files.readMember(reader, memberName, build_file_dir):
				continue
			if self.link_flags.readMember(reader, memberName, build_file_dir):
				continue
			#-------------------------
			if memberName == 'warning_as_error':
				self.warning_as_error = reader.getBool()
				continue
			if memberName == 'warning_level':
				self.warning_level = reader.getString()
				continue
			if self.disable_warning.readMember(reader, memberName, build_file_dir):
				continue

			if memberName == "xcode_settings":
				util.dictAdd(self.xcode_settings, reader.getDict())
				continue

			reader.error("Error: Unknown option " + memberName)				

	def dump(self):
		util.log("-------------------------------")
		if self.project is None:
			util.log("Config: [-Global-][" + self.name + "]")
		else:
			util.log("Config: [" + self.project.name + "]["+ self.name + "]")

		util.log("  {:22} = {}".format("output_target", self.output_target))

		if self.warning_level is not None:
			util.log("  {:22} = {}".format("warning_level", self.warning_level))
		if self.warning_as_error is not None:
			util.log("  {:22} = {}".format("warning_as_error", self.warning_as_error))
			
		indent = 14
		self.cpp_defines.dump()
		self.cpp_flags.dump()
		self.include_dirs.dump(True, indent)
		self.link_dirs.dump(True, indent)
		self.link_files.dump(True, indent)
		self.link_flags.dump()
		self.disable_warning.dump()
		if len(self.xcode_settings):
			util.log("  {:22} = {}".format("xcode_settings", util.toStr(self.xcode_settings, True, indent)))
