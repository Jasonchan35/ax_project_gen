from collections import OrderedDict
from ProjectGen import util, Config, FileEntry

class Project:
	def __init__(self, buildSettings):
		self.internal_resolving = False
		self.internal_resolved  = False
		self.bs = buildSettings

		self.build_file_dir = ""
		self.name = ""
		self.category = None
		self.type = "" #cpp_exe, cpp_lib, cpp_dll
		self.gui_app = False
		self.configs = OrderedDict()
		self.dependencies = OrderedDict()

		self.files = OrderedDict()
		self.exclude_files = OrderedDict()

		self.fileEntries = []
		self.pch_header = None

		self.output_target = ""
		self.output_target_prefix = ""
		self.output_target_suffix = ""
		self.output_target_dir = ""

		self.xcode_bundle_identifier = None
		self.xcode_info_plist_file = None

		self.unite_build = self.bs.unite_build
		self.unite_mega_byte_per_file = self.bs.unite_mega_byte_per_file

		self.generatedDir = None
		self.generatedUniteFileEntries = []

		for config_name in self.bs.configs.keys():
			c = Config.Config(buildSettings, self, config_name)
			self.configs[config_name] = c

	def _genUniteFile(self, fileType):
		cur_file = None
		cur_size = 0
		code = ""
		byte_size_per_file = self.unite_mega_byte_per_file * 1024 * 1024

		for e in self.fileEntries:
			e.buildNeeded = False
			if e.type == fileType:
				#create unite file
				if cur_file is None:
					tmp = "{}{}-UNITE_{:02d}{}".format(self.generatedDir, self.name, len(self.generatedUniteFileEntries), fileType)
					cur_file = util.absFilePath(tmp)
					code = '//-- Auto Generated File for Unite Build\n'

				code += '#include "'+ e.filename +'"\n'
				cur_size += util.fileSize(e.filename)

				if cur_size > byte_size_per_file:
					util.writeFile(cur_file, code)
					e = FileEntry.FileEntry(self, cur_file)
					self.generatedUniteFileEntries.append(e)
					code = ""
					cur_file = None
					cur_size = 0

		if cur_file is not None:
			util.writeFile(cur_file, code)
			e = FileEntry.FileEntry(self, cur_file)
			self.generatedUniteFileEntries.append(e)		

	def _resolveFiles(self):
		self.generatedDir = '{}_generated_/{}/'.format(self.bs.outdir, self.name)

		o = {}
		rel = util.relFilePath(self.build_file_dir)

		for p in self.files:
			for f in util.glob(rel + "/" + p):
				f = util.absFilePath(f)
				if util.isDir(f):
					continue
				key = f.lower()
				o[key] = f

		for p in self.exclude_files:
			for f in util.glob(rel + "/" + p):
				f = util.absFilePath(f)
				key = f.lower()
				if key in o:
					del o[key]

		tmp = [str(x) for x in o.values()]
		tmp.sort()

		self.fileEntries = []
		for x in tmp:
			e = FileEntry.FileEntry(self, x)
			self.fileEntries.append(e)

		if self.unite_build:
			if len(self.generatedUniteFileEntries):
				raise Exception("Unite file already generated")

			self.generatedUniteFileEntries = []
			self._genUniteFile(".c")
			self._genUniteFile(".cpp")

	def readJson(self, reader):
		if not reader.beginObject():
			reader.error('project must starts with {')

		self.build_file_dir = util.absDirname( reader.filename )

		while not reader.endObject():
			memberName = reader.getMemberName()
			if memberName == 'name':
				self.name = reader.getString()
			elif memberName == 'category':
				self.category = self.bs.getProjectCategory(reader.getString())
				self.category.projects.append(self)
			elif memberName == 'type':
				self.type = reader.getString()
			elif memberName == 'unite_build':
				self.unite_build = reader.getBool()
			elif memberName == 'unite_mega_byte_per_file':
				self.unite_mega_byte_per_file = reader.getNumber()
			elif memberName == 'gui_app':
				self.gui_app = reader.getBool()
			elif memberName == 'xcode_bundle_identifier':
				self.xcode_bundle_identifier = reader.getString()
			elif memberName == 'pch_header':
				self.pch_header = util.addBaseDir(reader.getString(), self.build_file_dir)
			elif memberName == 'files':
				util.dictAdd(self.files, reader.getStringArray(), None)
			elif memberName == 'exclude_files':
				util.dictAdd(self.exclude_files, reader.getStringArray(), None)
			elif memberName == 'dependencies':
				util.dictAdd(self.dependencies, reader.getStringArray(), None)
			elif memberName == 'config':
				for config in self.configs.values():
					r = reader.clone()
					config.readJson(r, self.build_file_dir)
				reader.skipValue()
			else:
				reader.error("Unknown config " + memberName)


	def resolve(self):
		if self.internal_resolved:
			return
		self.internal_resolved = True

		if self.internal_resolving:
			raise Exception("Cycle dependencies in project '" + self.name + "'")
		self.internal_resolving = True

		if self.name.find(' ') != -1:
			raise Exception('project name "' + self.name + '" contains space')

		self._resolveFiles()

		if self.xcode_bundle_identifier is None:
			self.xcode_bundle_identifier = 'com.my_company.' + self.name

		if self.xcode_info_plist_file is None:
			self.xcode_info_plist_file = self.name + "_info.plist"

		#--------------------
		carry_dependencies = OrderedDict()

		for k, d in self.dependencies.items():
			if k not in self.bs.projects:
				raise Exception("Cannot find dependency project ''" + k + "' for project '" + self.name + "'")
			
			dep_proj = self.bs.projects[k]
			if dep_proj == self:
				raise Exception("project depends on itself, project='" + self.name + "'")

			dep_proj.resolve() # resolve dependency project first
			self.dependencies[k] = dep_proj

			#carry depends project's dependencies
			util.dictAdd(carry_dependencies, dep_proj.dependencies)

		util.dictAdd(self.dependencies, carry_dependencies)

		#--------------------

		default_output_dir = ""
		if self.type == "cpp_exe":
			default_output_dir = "bin/"
			self.output_target_prefix = self.bs.cpp_exe_target_prefix
			self.output_target_suffix = self.bs.cpp_exe_target_suffix

		elif self.type == "cpp_lib":
			default_output_dir = "lib/"
			self.output_target_prefix = self.bs.cpp_lib_target_prefix
			self.output_target_suffix = self.bs.cpp_lib_target_suffix

		elif self.type == "cpp_dll":
			default_output_dir = "bin/"
			self.output_target_prefix = self.bs.cpp_dll_target_prefix
			self.output_target_suffix = self.bs.cpp_dll_target_suffix
		else:
			raise Exception('unknown project type = ' + self.type)

		self.output_target = self.output_target_prefix + self.name + self.output_target_suffix

		for config_name in self.bs.configs:
			config = self.configs[config_name]
			config.carryConfig(self.bs.configs[config_name])

			#--- carry dependencies configs
			for dep_proj in self.dependencies.values():
				dep_config = dep_proj.configs[config_name]
				config.carryConfig(dep_config)

			if len(config.output_dir) == 0:
				config.output_dir = util.absFilePath( self.bs.outdir + default_output_dir + config_name)
			config.output_target = config.output_dir + '/' + self.output_target

			if len(config.output_target) > 0:
				util.dictAdd(config.link_files.export,	config.output_target)

			config.resolve()
		#--------------------
		self.internal_resolving = False

	def dump(self):
		indent = 11
		util.log("")
		util.log("=============== Project " + self.name + " =================")
		util.log("  {:16} = {}".format("build_file_dir", self.build_file_dir))
		util.log("  {:16} = {}".format("type", self.type))
		util.log("  {:16} = {}".format("dependencies", util.toStr(self.dependencies.keys())))

		if self.pch_header is not None:
			util.log("  {:16} = {}".format("pch_header", self.pch_header))
		
		util.log("  {:16} = {}".format("files",util.toStr(self.files.keys(), True, indent)))
		if len(self.exclude_files) > 0:
			util.log("  exclude_files = " + util.toStr(self.exclude_files))
		#for v in self.fileEntries:
		#	v.dump()
		for v in self.configs.values():
			v.dump()
