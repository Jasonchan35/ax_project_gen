__all__ = [
	"axJson",
	"BuildSettings",
	"Config",
	"Project",
	"gen_vs2015",
	"gen_vs2015_linux",
	"gen_xcode",
	"gen_makefile",
	"gen_monodevelop",
	"gen_codeblock"]