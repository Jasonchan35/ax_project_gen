from collections import OrderedDict
from ProjectGen import util

class ProjectCategory:
	def __init__(self, parent, name):
		self.name = name
		self.fullpath = name
		self.parent = None

		if parent is not None:
			self.parent = parent
			parent.children[name] = self
			self.fullpath = parent.fullpath + '/' + name

		self.children = OrderedDict()
		self.projects = []

	def getChild(self, name):
		if name in self.children:
			return self.children[name]
		return ProjectCategory(self, name)
		