from ProjectGen import util, Config, Project, ProjectCategory, axJson
from collections import OrderedDict
import copy

class BuildSettings:
	def __init__(self):
		self.workspace_file = None
		self.workspace_name = "Unnamed"
		self.host_cpu = None
		self.host_os = None
		self.cpu = None
		self.os  = None
		self.platform  = None
		self.compiler = None
		self.generator = None
		self.startup_project = None
		self.default_config = ""

		self.cpp_objcpp = False
		self.cpp_exe_target_prefix = ""
		self.cpp_exe_target_suffix = ".exe"
		self.cpp_lib_target_prefix = ""
		self.cpp_lib_target_suffix = ".lib"
		self.cpp_dll_target_prefix = ""
		self.cpp_dll_target_suffix = ".dll"

		self.multithread_build = True
		self.unite_build = True
		self.unite_mega_byte_per_file = 1

		self.projects  = OrderedDict()
		self.configs   = OrderedDict()		

		self.root_project_category = ProjectCategory.ProjectCategory(None, "ProjectCategory#")
		self.project_categories = []

	def getProjectCategory(self, path):
		tmp = path.split("/")
		p = self.root_project_category
		for t in tmp:
			p = p.getChild(t)
		return p

	def addConfig(self, config_name):
		if config_name in self.configs:
			raise Exception("Config '" + config_name + "' already exists")

		util.log("+Config '" + config_name + "'")
		o = Config.Config(self, None, config_name)
		self.configs[config_name] = o
		return o

	def addProject(self, p):
		if p.name in self.projects:
			raise Exception("Project '" + p.name + "' already exists")
		self.projects[p.name] = p
		return p

	def resolveProjects(self):
		for k, p in self.projects.items():
			p.resolve()

	def dump(self):
		util.log("\n=== BuildSettings ===")
		util.log("workspace_name    = " + self.workspace_name)
		util.log("multithread_build = " + str(self.multithread_build))
		if self.startup_project is not None:
			util.log("startup_project   = " + self.startup_project)

		for k, v in self.configs.items():
			v.dump()
		for k, v in self.projects.items():
			v.dump()

	'''
	def readConfig(self, config):
		if type(config) is list:
			for v in config:
				self.readConfig(v)
			return
		self.addConfig(config)

	def readProject(self, reader):
		name = name[len('project:'):]
		util.log("+Project '" + name + "'")
		o = Project.Project(self)
		o.name = name
		o.build_file_dir = build_file_dir
		o.readJson(json_obj)
		self.addProject(o)
	'''

	def readBuildFile(self, build_file_dir, filename):
		if type(filename) is list:
			for v in filename:
				self.readBuildFile(build_file_dir, v)
			return

		filename = build_file_dir + '/' + filename
		util.log("readBuildFile '" + filename + "'")

		build_file_dir = util.absDirname(filename)
		reader = axJson.Reader()
		reader.openFile(filename)

		ext = util.fileExt(filename)
		basename = util.basename(filename, False)

		if (ext == ".axproj"):
			proj = Project.Project(self)
			proj.name = basename
			self.addProject(proj)
			proj.readJson(reader)
		else:
			raise "Unknwon build file " + filename

	def readMasterFile(self, filename):
		filename = util.absFilePath(filename)
		util.log("readMasterFile '" + filename + "'")
		build_file_dir = util.absDirname(filename)

		reader = axJson.Reader()
		reader.openFile(filename)

		if not reader.beginObject():
			reader.error('File must starts with {')

		while not reader.endObject():
			memberName = reader.getMemberName()

			if memberName == 'workspace_name':
				self.workspace_name = reader.getString()
			elif memberName == 'startup_project':
				self.startup_project = reader.getString()
			elif memberName == 'default_config':
				self.default_config = reader.getString()
			elif memberName == 'multithread_build':
				self.multithread_build = reader.getBool()
			elif memberName == 'unite_build':
				self.unite_build = reader.getBool()
			elif memberName == 'unite_mega_byte_per_file':
				self.unite_mega_byte_per_file = reader.getNumber()				
			elif memberName == 'config_list':
				for v in reader.getStringArray():
					self.addConfig(v)

			elif memberName == 'build_files':
				for v in reader.getStringArray():
					self.readBuildFile(build_file_dir, v)

			elif memberName == 'config':
				for config in self.configs.values():
					r = reader.clone()
					config.readJson(r, build_file_dir)
				reader.skipValue()

			else:
				reader.error("Error: Unknown option " + memberName)

	def resolveProjectCategory(self, cat):
		if cat is not self.root_project_category:
			self.project_categories.append(cat)
		for c in cat.children.values():
			self.resolveProjectCategory(c)

	def resolve(self):
		if self.workspace_name.find(' ') != -1:
			raise Exception('workspace_name "' + self.workspace_name + '" contains space')

		if len(self.default_config) == 0 and len(self.configs):
			first = list(self.configs.values())[0]
			self.default_config = first.name

		if self.os == "windows":
			self.cpp_exe_target_prefix = ""
			self.cpp_exe_target_suffix = ".exe"
			self.cpp_lib_target_prefix = ""
			self.cpp_lib_target_suffix = ".lib"
			self.cpp_dll_target_prefix = ""
			self.cpp_dll_target_suffix = ".dll"
		else:
			self.cpp_exe_target_prefix = ""
			self.cpp_exe_target_suffix = ""
			self.cpp_lib_target_prefix = "" # "lib"
			self.cpp_lib_target_suffix = ".a"
			self.cpp_dll_target_prefix = ""
			self.cpp_dll_target_suffix = ".so"

		self.project_categories = []
		self.resolveProjectCategory(self.root_project_category)

		self.resolveProjects()
