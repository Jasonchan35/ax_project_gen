import uuid
import xml.etree.ElementTree as ETree
from collections import OrderedDict
from ProjectGen import util

bs = None
output_cpu = ""
output_os = ""

def genUuid():
	return str(uuid.uuid4()).upper()

def gen_cproj_folders(project, files, node_proj):
	dirs = OrderedDict()
	for f in files:
		rel = util.relFilePath(f, project.build_file_dir)
		d = util.dirname(rel)

		# extract all directory along the path
		dd = util.windowsFilePath(util.dirname(d))
		if not dd in dirs:
			dirs[dd] = []

		# add file to dirs dict
		d = util.windowsFilePath(d)
		f = util.windowsFilePath(f)
		if d in dirs:
			dirs[d].append(f)
		else:
			dirs[d] = [f]

	# Folders
	node_item_group = ETree.SubElement(node_proj, "ItemGroup")
	for d in dirs:
		if len(d) > 0:
			ETree.SubElement(node_item_group, "Folder", attrib = {"Include":d + '\\'})

def gen_project(project):
	util.log("gen_project " + project.name)

	filename = bs.outdir + project.name + ".cproj"
	project.filename = filename

	node_proj = ETree.Element("Project", attrib = {
		"DefaultTargets":"Build",
		"ToolsVersion":"12.0",
		"xmlns":"http://schemas.microsoft.com/developer/msbuild/2003"
	})


	node_prop_group = ETree.SubElement(node_proj, "PropertyGroup")
	ETree.SubElement(node_prop_group, "Configuration", attrib = {
		"Condition":" '$(Configuration)' == '' "
	}).text = bs.default_config

	ETree.SubElement(node_prop_group, "Platform", attrib = {
		"Condition":" '$(Platform)' == '' "
	}).text = "AnyCPU"


	ETree.SubElement(node_prop_group, "ProjectGuid").text = "{" + project.uuid + "}"
	node_compiler = ETree.SubElement(node_prop_group, "Compiler")
	ETree.SubElement(node_compiler, "Compiler", attrib = {
		"ctype":"GccCompiler"
	})

	ETree.SubElement(node_prop_group, "Language").text = "CPP"
	ETree.SubElement(node_prop_group, "Target").text = "Bin"

	for config_name, config in project.configs.items():
		node_prop_group = ETree.SubElement(node_proj, "PropertyGroup", attrib = {
			"Condition":" '$(Configuration)|$(Platform)' == '" + config_name + '|' + output_cpu + "'"
		})

		if config_name == "Debug":
			ETree.SubElement(node_prop_group, "DebugSymols").text = "true"
		else:
			ETree.SubElement(node_prop_group, "DebugSymols").text = "false"

		ETree.SubElement(node_prop_group, "OutputPath").text = "bin\\" + config_name
		ETree.SubElement(node_prop_group, "OutputName").text = project.name

		if project.type == "cpp_lib":
			ETree.SubElement(node_prop_group, "CompileTarget").text = "StaticLibrary"
		elif project.type == "cpp_lib":
			ETree.SubElement(node_prop_group, "CompileTarget").text = "Bin"


		ETree.SubElement(node_prop_group, "DefineSymbols").text = ' '.join(config.cpp_defines)
		ETree.SubElement(node_prop_group, "SourceDirectory").text = "."
		#---------------
		cpp_flags = ""
		if config.pch_header:
			cpp_flags = '-include "' + util.absFilePath(project.build_file_dir + '/' + config.pch_header) + '" '
		cpp_flags += ' '.join(config.cpp_flags)
		ETree.SubElement(node_prop_group, "ExtraCompilerArguments").text = cpp_flags
		ETree.SubElement(node_prop_group, "ExtraLinkerArguments").text   = ' '.join(config.link_flags)

		node_includes = ETree.SubElement(node_prop_group, "Includes")
		node_includes = ETree.SubElement(node_includes, "Includes")
		for p in config.include_dirs:
			ETree.SubElement(node_includes, "Include").text = p
		#---------------
		node_libPaths = ETree.SubElement(node_prop_group, "LibPaths")
		node_libPaths = ETree.SubElement(node_libPaths, "LibPaths")
		for p in config.link_dirs:
			ETree.SubElement(node_libPaths, "LibPath").text = p

	# source file group
	node_item_group = ETree.SubElement(node_proj, "ItemGroup")
	files = []

	#pch_source = util.basename(config.pch_source,True)

	for abs_f in project.getFiles():
		f = util.relFilePath(abs_f, bs.outdir)
		f = util.windowsFilePath(f)
		files.append(f)
		#basename = util.basename(f, True)
		ext = util.fileExt(f)
		if ext == ".cpp" or ext == ".cc" or ext == ".cxx":
			node_file = ETree.SubElement(node_item_group, "Compile", attrib = {"Include":f})
			#if basename == pch_source:
			#	ETree.SubElement(node_cl, "PrecompiledHeader").text = "Create"
		else:
			node_file = ETree.SubElement(node_item_group, "None", attrib = {"Include":f})

		virtual_path = util.relFilePath(abs_f, project.build_file_dir)
		virtual_path = util.windowsFilePath(virtual_path)
		#virtual_path = virtual_path.replace('..\\','')
		ETree.SubElement(node_file, "Link").text =  virtual_path

	#gen_cproj_folders(project, files, node_proj)

	util.writeXmlFile(filename, node_proj)

def gen_workspace():
	util.log("gen_workspace " + bs.workspace_name)
	workspace_name = bs.workspace_name + "_" + bs.platform
	filename = bs.outdir + workspace_name + ".sln"
	cache_filename = bs.outdir + "/ax_build_cache.json"

	o = util.OutBuffer()
	o.writeln("")
	o.writeln('Microsoft Visual Studio Solution File, Format Version 12.00')
	o.writeln('# Visual Studio 2012')

	cache = OrderedDict()

	if util.fileExists(cache_filename):
		cache = util.readJsonFile(cache_filename)

	if "projects_uuid" not in cache:
		cache["projects_uuid"] = OrderedDict()

	projects_uuid = cache["projects_uuid"]

	for k, project in bs.projects.items():
		if k in projects_uuid:
			prev_uuid = projects_uuid[k]
			project.uuid = prev_uuid
		else:
			project.uuid = genUuid()
			projects_uuid[k] = project.uuid

		gen_project(project)

	for k, project in bs.projects.items():
		o.writeln('Project("{2857B73E-F847-4B02-9238-064979017E93}") = "' + project.name + '", "' + util.relFilePath(project.filename, bs.outdir) + '", "{'+ project.uuid +'}"')
		o.writeln('EndProject')

	o.writeln('Global')

	o.writeln('\tGlobalSection(SolutionConfigurationPlatforms) = preSolution')
	for config_name in bs.configs.keys():
		c = config_name + '|' + output_cpu
		o.writeln('\t\t' + c + ' = ' + c)
	o.writeln('\tEndGlobalSection')

	o.writeln('\tGlobalSection(ProjectConfigurationPlatforms) = postSolution')
	for proj in bs.projects.values():
		for config_name in proj.configs.keys():
			c = config_name + '|' + output_cpu
			o.writeln('\t\t{' + proj.uuid + '}.' + c + '.ActiveCfg = ' + c)
			o.writeln('\t\t{' + proj.uuid + '}.' + c + '.Build.0   = ' + c)
	o.writeln('\tEndGlobalSection')

	o.writeln('EndGlobal')


	util.writeFile(filename, o.getValue())
	util.writeJsonFile(cache_filename, cache)

def generate():
	global output_cpu
	#global output_os

	if bs.cpu == "x86":
		output_cpu = "Win32"
	elif bs.cpu == "x86_64":
		output_cpu = "x64"
	else:
		raise Exception("Unsupport cpu type " + bs.cpu)

	gen_workspace()

def init(buildSettings):
	global bs
	bs = buildSettings
	bs.generator = "monodevelop"

	if bs.compiler is None:
		bs.compiler = "msvc"
