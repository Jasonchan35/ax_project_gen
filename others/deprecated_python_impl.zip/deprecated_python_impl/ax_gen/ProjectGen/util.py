import os
import io
import json
import sys
import subprocess

import xml.dom.minidom as minidom
from xml.dom.minidom import getDOMImplementation

import xml.etree.ElementTree as xmlElementTree
from collections import OrderedDict, KeysView
from pathlib import Path

g_logFile = None

def openLogFile(filename):
	global g_logFile
	closeLogFile()
	print("log file = " + filename)
	folder = os.path.dirname(filename)
	createFolder(folder)	
	g_logFile = open(filename, "w")

def log(msg, file=sys.stdout):
	global g_logFile
	print(msg)
	if g_logFile is not None:		
		g_logFile.write(msg + "\n")
		g_logFile.flush()

def closeLogFile():
	global g_logFile
	if g_logFile is not None:
		g_logFile.close()
		g_logFile = None

#----------------------

def shell_run(cmd):
	os.system(cmd)

def shell_exec(args):
	#os.system(cmd)
	log('run shell command = ' + str(args) + '\n')
	#p = subprocess.Popen(args, shell=False)
	p = subprocess.Popen(args, bufsize=(16 * 1024), shell=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
	
	(out,err) = p.communicate()
	log(out.decode('utf8'))
	log(err.decode('utf8'))

	p.wait()
	log('\n--- cmd ended return:' + str(p.returncode) + '\n')

#----------------------
class OutBuffer:
	def __init__(self):
		self.o = io.StringIO()
		self.indent = 0
		self.indentString = "  "

	def addIndent(self):
		self.indent += 1

	def subIndent(self):
		self.indent -= 1

	def write(self, s):
		self.o.write(s)

	def writeln(self, s):
		self.o.write(s)
		self.newline()

	def newline(self, addIndent = 0):
		self.o.write("\n")
		self.indent += addIndent
		for _ in range(0, self.indent):
			self.o.write(self.indentString)

	def getValue(self):
		return self.o.getvalue()

	def close(self):
		self.o.close()

#---------- string -----------

def getStringFromPrefix(s, prefix):
	if s.startswith(prefix):
		return s[len(prefix):]
	return ""

def toStr(src, newline=False, indent=0):
	t = type(src)
	if t is OrderedDict:
		o = OutBuffer()
		o.write("{")
		o.indent = indent
		i = 0
		for k, v in src.items():
			if newline and i > 0:
				o.newline()
			o.write("{:30}: {}".format(k,v))
			i += 1
		o.write("}")
		s = o.getValue()
		o.close()
		return s

	elif issubclass(t, KeysView):
		return toStr(list(src), newline, indent)

	elif t is list:
		if not newline:
			return str(src)
		else:
			o = OutBuffer()
			o.write("[")
			o.indent = indent
			i = 0
			for v in src:
				if newline and i > 0:
					o.newline()
				o.write(v)
				i += 1
			o.write("]")
			s = o.getValue()
			o.close()
			return s
	else:
		return str(src)


#------- file path -----------------
def fileExists(path):
	return os.path.exists(path)

def posixFilePath(path):
	return path.replace("\\", "/")

def glob(s):
	o = []
	for f in Path('.').glob(s):
		o.append( posixFilePath( str(f) ) )
	return o

def windowsFilePath(path):
	return path.replace("/", "\\")

def relFilePath(path, dir = None):
	if dir is None:
		dir = os.getcwd()
	return posixFilePath(os.path.relpath(path, dir))

def absFilePath(path):
	return posixFilePath(os.path.abspath(path))

def absWindowsFilePath(path):
	return windowsFilePath(os.path.abspath(path))

def absDirname(path):
	return dirname( absFilePath(path) )

def relDirname(path, rel):
	return dirname( relFilePath(path, rel) )

def isDir(path):
	return os.path.isdir(path)
	
def dirname(filename):
	return posixFilePath(os.path.dirname(filename))

def basename(path, withExt):
	if withExt:
		return os.path.basename(path)
	else:
		name, ext = os.path.splitext(os.path.basename(path))
		return name

def fileExt(path):
	basename, ext = os.path.splitext(path)
	return ext

def fileSize(path):
	return os.stat(path).st_size 

def addBaseDir(src, baseDir):
	if type(src) is list:
		return [addBaseDir(e, baseDir) for e in src]
	if os.path.isabs(src):
		return src
	else:
		return absFilePath(baseDir + '/' + src)

#---------- dict --------------
def dictAdd(dict, src, value = None):
	t = type(src)
	if t is list:
		for e in src:
			dict[e] = value
	elif t is OrderedDict or t is dict:
		for k,v in src.items():
			dict[k] = v
	elif t is str:
		dict[src] = value
	else:
		raise Exception("Unsupported type " + str(t)) 

#----------- list ----------------------
def appendDict(o, d):
	for k, v in d.items():
		o[k] = v

def appendOrExtendList(o, v):
	if type(v) is list:
		o.extend(v)
	else:
		o.append(v)

def uniqueAppendList(o, v):
	if type(v) is list:
		for p in v:
			uniqueAppendList(o, p)
		return
	if not v in o:
		o.append(v)

def removeDuplicatedFromList(o):
	d = OrderedDict((k, None) for k in o)
	return list(d.keys())

#------ File IO -----------------------------
def readJsonFile(filename):
	if not fileExists(filename):
		raise Exception('file does not exists "' + filename +'"')
	fp = open(filename, 'r')
	return json.load(fp, object_pairs_hook=OrderedDict)

def writeJsonFile(filename, value):
	fp = open(filename, 'w')
	json.dump(value, fp, indent = 2)

def createFolder(directory):
	if not os.path.exists(directory):
		os.makedirs(directory)

def readFile(filename):
	if not fileExists(filename):
		raise Exception('file does not exists "' + filename +'"')
	fp = open(filename, 'r')
	s = fp.read()
	return s

def writeFile(filename, contentString):
	t = "+" # new file
	if os.path.exists(filename):
		t = "U" # update
		if contentString == readFile(filename):
			t = "=" # same

	log("["+t+"] " + filename)
	if t == "=":
		return
	folder = os.path.dirname(filename)
	createFolder(folder)
	fp = open(filename, 'w')
	fp.write(contentString)
	fp.close()

def writeXmlFile(filename, element_tree_node, doctype = None):
	dom = minidom.parseString(xmlElementTree.tostring(element_tree_node))
	if doctype is not None:
		imp = getDOMImplementation()

		publicId = ''
		if 'publicId' in doctype:
			publicId = doctype['publicId']
		systemId = ''
		if 'systemId' in doctype:
			systemId = doctype['systemId']

		doctype_node = imp.createDocumentType(  
			qualifiedName = doctype['name'],
			publicId = publicId,
			systemId = systemId)

		dom.insertBefore(doctype_node, dom.childNodes[0])

	s = str(dom.toprettyxml(indent="  ", encoding="utf-8"), "utf8")
	writeFile(filename, s)

