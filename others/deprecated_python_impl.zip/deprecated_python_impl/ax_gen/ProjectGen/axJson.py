import os
import copy
from collections import OrderedDict
from ProjectGen import util

class Reader:
	class JsonError(BaseException):
		def __init__(self, reader, msg):
			o = ('JsonError: ' + msg
				+ '\n  File: ' + reader.filename + ':' + str(reader.line)
				+ reader.getSourceLines()
				)
			raise Exception(o)

	def __init__(self):
		self.filename = ""
		self.cur = 0
		self.line = 1
		self.json = ""
		self.value = None
		self.valueType = None

	def clone(self):
		o = copy.deepcopy(self)
		return o

	def error(self, msg):
		raise self.JsonError(self, msg)

	def warning(self, msg):
		o = ('JsonWarning: ' + msg
			+ '\n  File: ' + self.filename + ':' + str(self.line)
			+ self.getSourceLines()
			)
		util.log(o)

	def getSingleSourceLine(self, pos, line_no):
		json = self.json
		start = pos
		end   = len(json)

		if pos >= end:
			return "", pos

		for i in range(pos, 0, -1):
			if json[i] == '\n':
				start = i + 1
				break

		for i in range(pos, len(json)):
			if json[i] == '\n':
				end = i
				break

		o = '\n  line {0:4d} : '.format(line_no)
		o += json[start:end].replace('\t', '    ')
		return o, start

	def getSourceLines(self):
		json = self.json
		cur = self.cur
		lineStart = cur

		numLinesToShow = 3
		o = []
		tmp = cur
		for i in range(numLinesToShow):
			line_no = self.line - i
			if line_no < 1:
				break

			line, tmp = self.getSingleSourceLine(tmp - 1, line_no)
			if i == 0:
				lineStart = tmp
			tmp -= 1
			o.append(line)

		o.reverse()

		arrow = "\n            :"
		for c in json[lineStart:cur]:
			if c == '\t':
				arrow += '----'
			else:
				arrow += '-'

		arrow += '^\n\n'
		o.append(arrow)
		return ''.join(o)

	def skipSingleLineComment(self):
		while True:
			ch = self.nextChar()
			if ch == '\n' or ch is None:
				ch = self.nextChar()
				break
		return ch

	def skipBlockComment(self):
		ch = self.nextChar()
		while True:
			if ch is None:
				break

			if ch == '*':
				ch = self.nextChar()
				if ch == '/':
					ch = self.nextChar()
					break
			else:
				ch = self.nextChar()
				
		return ch

	def charToHex(self, ch):
		if len(ch) == 1:
			i = ord(ch)
			if i >= ord('0') and i <= ord('9'):
				return i - ord('0')

			if i >= ord('a') and i <= ord('f'):
				return i - ord('a') + 10

			if i >= ord('A') and i <= ord('F'):
				return i - ord('A') + 10

		self.error('invalid hex character ' + ch)

	def parseString(self):
		o = ""
		while True:
			ch = self.nextChar()
			if ch is None:
				self.error('unexpected end of file in side string')
			if ch == '"':
				break

			if ch == '\\':
				ch = self.nextChar()
				if ch == '\"':
					o += ch
				elif ch == '\\':
					o += ch
				elif ch == '/':
					o += ch
				elif ch == 'b':
					o += '\b'
				elif ch == 'f':
					o += '\f'
				elif ch == 'n':
					o += '\n'
				elif ch == 'r':
					o += '\r'
				elif ch == 't':
					o += '\t'
				elif ch == 'u':
					ch = self.nextChar()
					v = self.charToHex(ch)
					ch = self.nextChar()
					v = v * 16 + self.charToHex(ch)
					ch = self.nextChar()
					v = v * 16 + self.charToHex(ch)
					ch = self.nextChar()
					v = v * 16 + self.charToHex(ch)
					o += chr(v)
				else:
					self.error('invalid escape character "'+ ch + '" in string')
				continue

			o += ch

		return o, True

	def nextChar(self):
		if self.cur >= len(self.json):
			return None

		ch = self.json[self.cur]
		self.cur += 1

		if ch == '\n':
			self.line += 1

		#util.log('=========> ch = ' + ch + ' ' + str(ord(ch)))
		return ch

	def nextToken(self):
		#return self._nextTokenDebug()
		return self._nextToken()

	def _nextTokenDebug(self):
		token, isStr = self._nextToken()
		o = ""
		if isStr:
			o += '"' + token + '"'
		elif token is None:
			o += "<None>"
		else:
			o += token

		util.log('=========> token = ' + o)
		return token, isStr

	def trimSpaces(self, ch):
		while True:
			if ch is None:
				return None

			if ch in "\r\n\t ":
				ch = self.nextChar()
				continue
			break
		return ch

	def _nextToken(self):
		ch = self.nextChar()
		ch = self.trimSpaces(ch)

		self.value = None
		token = ""
		isStr = False
		while True:
			if ch is None:
				return None, False

			if ch in [':', ',', '[', ']', '{', '}']:
				if len(token) > 0:
					return token, isStr
				else:
					return ch, False

			if ch == '"':
				return self.parseString()

			if ch == '/':
				ch = self.nextChar()
				if ch == '/':
					ch = self.skipSingleLineComment()
				elif ch == '*':
					ch = self.skipBlockComment()
				else:
					self.error('unexpected charactor "' + ch + '" after "/" ')
				ch = self.trimSpaces(ch)
				continue

			if ch is not None:
				token += ch

			ch = self.nextChar()

		return token, False

	def nextValue(self):
		r = self._nextValue()
		#util.log('=========> valueType = "' + str(self.valueType) + '" ' + str(self.value))
		return r

	def _nextValue(self):
		self.value = None
		self.valueType = None

		token, isStr = self.nextToken()

		if token is None:
			return

		if isStr:
			self.value = token
			self.valueType = "string"
			return

		if token in ['{','}','[', ']', ':', ',']:
			self.valueType = token
			return

		if token == 'null':
			self.valueType = 'null'
			self.value = None
			return

		if token == 'true':
			self.valueType = 'bool'
			self.value = True
			return

		if token == 'false':
			self.valueType = 'bool'
			self.value = False
			return

		try:
			self.value = float(token)
			self.valueType = 'number'
			return
		except ValueError:
			pass

		self.error('Unknown token ' + token)


	def openFile(self, filename):
		if not os.path.exists(filename):
			raise Exception('file does not exists "' + filename +'"')
		fp = open(filename, 'r')
		self.filename = filename
		self.json = fp.read()

		self.nextValue()

	def trimComma(self):
		if self.valueType == ',':
			#util.log("===========> trimComma")
			self.nextValue()

	def beginObject(self):
		if self.valueType == '{':
			self.nextValue()
			return True
		return False

	def endObject(self):
		if self.valueType == '}':
			self.nextValue()
			self.trimComma()
			return True
		return False

	def beginArray(self):
		if self.valueType == '[':
			self.nextValue()
			return True
		return False

	def endArray(self):
		if self.valueType == ']':
			self.nextValue()
			self.trimComma()
			return True
		return False

	def getString(self):
		if self.valueType != 'string':
			self.error('is not string value (type = ' + self.valueType + ')')
			return

		o = self.value
		self.nextValue()
		self.trimComma()
		return o

	def getStringArray(self):
		o = []
		if not self.beginArray():
			self.error('string array expected')
			return

		while not self.endArray():
			o.append( self.getString() )
		return o

	def getDict(self):
		o = OrderedDict()
		if not self.beginObject():
			self.error('{ expected')
		while not self.endObject():
			m = self.getMemberName()
			v = self.getString()
			o[m] = v
		return o

	def getNumber(self):
		if self.valueType != 'number':
			self.error('is not number value (type = ' + self.valueType + ')')
			return

		o = self.value
		self.nextValue()
		self.trimComma()
		return o

	def getBool(self):
		if self.valueType != 'bool':
			self.error('is not bool value (type = ' + self.valueType + ')')

		o = self.value
		self.nextValue()
		self.trimComma()
		return o

	def member(self, name):
		if self.valueType != 'string':
			self.error('member name != string type (type = ' + self.valueType + ')')
			return

		if self.value == name:
			self.nextValue()
			if self.valueType != ':':
				self.error("':' expected after object member name ")

			self.nextValue()
			return True
		else:
			return False

	def getMemberName(self):
		if self.valueType != 'string':
			self.error('member name != string type (type = ' + self.valueType + ')')
			return

		memberName = self.value
		self.nextValue()
		if self.valueType != ':':
			self.error("':' expected after object member name ")
		self.nextValue()

		return memberName

	def skipMember(self):
		#util.log("======> skipMember " + str(self.value))
		memberName = self.getMemberName()
		self.skipValue()
		return memberName

	def skipValue(self):
		#util.log("======> skipValue")
		if self.beginObject():
			while not self.endObject():
				self.skipMember()
			return

		if self.beginArray():
			while not self.endArray():
				self.skipValue()
			return

		if self.valueType == 'string':
			self.getString()
			return

		if self.valueType == 'bool':
			self.getBool()
			return

		if self.valueType == 'number':
			self.getNumber()
			return
