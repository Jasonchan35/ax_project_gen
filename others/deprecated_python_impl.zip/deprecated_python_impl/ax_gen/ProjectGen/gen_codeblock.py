import xml.etree.ElementTree as ETree
from ProjectGen import util, gen_makefile

bs = None

def gen_project(project):
	cbp_filename = bs.outdir + project.name + ".cbp"
	util.log("gen_project " + cbp_filename)

	node_cbp_proj = ETree.Element("CodeBlocks_project_file")
	ETree.SubElement(node_cbp_proj, "FileVersion", attrib = {
		"major":"1", "minor":"6"
	})

	node_proj = ETree.SubElement(node_cbp_proj, "Project")
	ETree.SubElement(node_proj, "Option", attrib={"title": project.name})
	ETree.SubElement(node_proj, "Option", attrib={"makefile": (project.name + ".make")})
	ETree.SubElement(node_proj, "Option", attrib={"makefile_is_custom": "1"})
	ETree.SubElement(node_proj, "Option", attrib={"pch_mode": "2"})
	ETree.SubElement(node_proj, "Option", attrib={"compiler": bs.compiler})

	node_make_cmds = ETree.SubElement(node_proj, "MakeCommands")
	ETree.SubElement(node_make_cmds, "Build", 				attrib={"command": 'echo "See_Config" '})
	ETree.SubElement(node_make_cmds, "CompileFile", 		attrib={"command": 'echo "See_Config" '})
	ETree.SubElement(node_make_cmds, "Clean", 				attrib={"command": 'echo "See_Config" '})
	ETree.SubElement(node_make_cmds, "DistClean", 			attrib={"command": 'echo "See_Config" '})
	ETree.SubElement(node_make_cmds, "AskRebuildNeeded", 	attrib={"command": 'echo "See_Config" '})
	ETree.SubElement(node_make_cmds, "SilentBuild", 		attrib={"command": 'echo "See_Config" '})

	node_build = ETree.SubElement(node_proj, "Build")
	for config_name, config in project.configs.items():
		node_target = ETree.SubElement(node_build, "Target", attrib={
			"title": config_name
		})

		if project.type == "cpp_exe":
			if project.gui_app:
				proj_type = "0"
			else:
				proj_type = "1"
		elif project.type == "cpp_lib":
			proj_type = "2"
		elif project.type == "cpp_dll":
			proj_type = "3"
		else:
			raise Exception('Unsupport project.type "' + project.type+ '"')

		ETree.SubElement(node_target, "Option", attrib={"output": util.relFilePath(config.output_target, bs.outdir)})
		ETree.SubElement(node_target, "Option", attrib={"working_dir": ""})
		ETree.SubElement(node_target, "Option", attrib={"object_output": "_build_tmp/Debug/" + project.name})
		ETree.SubElement(node_target, "Option", attrib={"type": proj_type})
		ETree.SubElement(node_target, "Option", attrib={"compiler": bs.compiler})
		ETree.SubElement(node_target, "Option", attrib={"createDefFile": "1"})

		gmake_options = ""
		if bs.multithread_build:
			gmake_options = "-j"

		node_make_cmds = ETree.SubElement(node_target, "MakeCommands")
		ETree.SubElement(node_make_cmds, "Build", 				attrib={"command": "$make " + gmake_options + " -f $makefile build config=$target"})
		ETree.SubElement(node_make_cmds, "CompileFile", 		attrib={"command": "$make " + gmake_options + " -f $makefile compile_file file=$file config=$target"})
		ETree.SubElement(node_make_cmds, "Clean", 				attrib={"command": "$make " + gmake_options + " -f $makefile clean config=$target"})
		ETree.SubElement(node_make_cmds, "DistClean", 			attrib={"command": "$make " + gmake_options + " -f $makefile dist_clean config=$target"})
		ETree.SubElement(node_make_cmds, "AskRebuildNeeded", 	attrib={"command": "$make " + gmake_options + " -q -f $makefile build config=$target"})
		ETree.SubElement(node_make_cmds, "SilentBuild", 		attrib={"command": "$make " + gmake_options + " -f $makefile build config=$target"})

	#---- Files -----------
	ETree.SubElement(node_proj, "Unit", attrib={
		"filename": util.relFilePath(project.filename, bs.outdir) # <project_name>.make
	})

	files = project.getFiles()
	for f in files:
		ETree.SubElement(node_proj, "Unit", attrib={
			"filename": util.relFilePath(f, bs.outdir)
		})


	util.writeXmlFile(cbp_filename, node_cbp_proj)

def gen_workspace_layout():
	workspace_layout_filename = bs.outdir + bs.workspace_name + ".workspace.layout"
	util.log("gen_workspace_layout " + workspace_layout_filename)

	node_workspace_layout_file = ETree.Element("CodeBlocks_workspace_layout_file")
	ETree.SubElement(node_workspace_layout_file, "FileVersion", attrib = {
		"major": "1", "minor": "0"
	})

	if len(bs.startup_project) > 0:
		ETree.SubElement(node_workspace_layout_file, "ActiveProject", attrib = {
			"path": bs.startup_project + '.cbp'
		})

	if len(bs.default_config) > 0:
		ETree.SubElement(node_workspace_layout_file, "PreferredTarget", attrib = {
			"name": bs.default_config
		})

	util.writeXmlFile(workspace_layout_filename, node_workspace_layout_file)

def gen_workspace():
	workspace_filename = bs.outdir + bs.workspace_name + ".workspace"
	util.log("gen_workspace " + workspace_filename)

	node_workspace_file = ETree.Element("CodeBlocks_workspace_file")
	node_workspace = ETree.SubElement(node_workspace_file, "Workspace", attrib = {
		"title": bs.workspace_name + " " + bs.platform
	})

	for project in bs.projects.values():
		gen_project(project)
		node_proj = ETree.SubElement(node_workspace, "Project", attrib = {
			"filename": project.name + '.cbp'
		})

		for dep_name in project.dependencies:
			ETree.SubElement(node_proj, "Depends", attrib = {
				"filename": dep_name + '.cbp'
			})

	util.writeXmlFile(workspace_filename, node_workspace_file)

def generate():
	gen_makefile.generate()
	gen_workspace()
	gen_workspace_layout()

def build():
	gen_makefile.build()

def run_target():
	gen_makefile.run_target()

def init(buildSettings):
	global bs
	bs = buildSettings
	bs.generator = "codeblock"

	gen_makefile.init(buildSettings)
	
	