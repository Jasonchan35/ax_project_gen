from ProjectGen import util
from collections import OrderedDict

class FileEntry:
    def __init__(self, project, filename):
        self.filename = filename
        self.project  = project
        self.buildNeeded = False

        self.basename = util.basename(filename, True)
        self.ext = util.fileExt(filename)
        self.generated = False

        self.isDir = util.isDir(filename)
        if self.isDir:
            self.type = "/"
        elif not self.isDir:
            if self.ext in [".cpp", ".cc", "cxx"]:
                self.type = ".cpp"
                self.buildNeeded = True

            elif self.ext in [".c"]:
                self.type = ".c"
                self.buildNeeded = True
                
            elif self.ext in [".h", ".hpp"]:
                self.type = ".h"

            else:
                self.type = ""

    def dump(self):
        util.log('  FileEntry: ' + self.filename)