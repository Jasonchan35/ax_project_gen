from ProjectGen import gen_vs2015

bs = None

def generate():
	if bs.generator != "vs2015_linux":
		raise Exception("invalid generator")

	gen_vs2015.generate()

#def build():
	#gen_vs2015.build()

#def run_target():
	#gen_vs2015.run_target()

def init(buildSettings):
	global bs
	bs = buildSettings

	if bs.generator is None:
		bs.generator = "vs2015_linux"

	if bs.compiler is None:
		bs.compiler = "gcc"	

	gen_vs2015.init(buildSettings)
