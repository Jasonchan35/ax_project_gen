from collections import OrderedDict
from ProjectGen import util

bs = None

make_multithread_flags = ''
pch_suffix = ".pch"

def escape_str(s):
	return s.replace(' ', '\\ ')

def quote_str(s):
	return '"' + s + '"'

def gen_common_var(o):
	global pch_suffix

	o.writeln('#!! Unix Makefile')
	o.writeln('#!! Works for pmake (FreeBSD), GNUmake (GNU Linux)')
	o.writeln('#!! ')

	o.writeln("config ?= " + bs.default_config)

	o.writeln("")
	o.writeln("space=$(empty) $(empty)")
	o.writeln("escape_str = $(subst $(space),\\\\\\$(space),$1)")
	o.writeln("qs = $(subst ?,$(sp),$1)")
	o.writeln("")

	if bs.compiler == "gcc":
		o.writeln("cmd_cc    := gcc")
		o.writeln("cmd_link  := gcc")
		pch_suffix = ".gch"
	else:
		o.writeln("cmd_cc    := clang")
		o.writeln("cmd_link  := clang")

	o.writeln("cmd_ar    := ar")

	if bs.host_os == "windows":
		o.writeln("cmd_mkdir := cmd.exe /c mkdir.bat")
		o.writeln("cmd_rmdir := rm -rf")
		o.writeln("cmd_copy  := cp -f")
	else:
		o.writeln("cmd_mkdir := mkdir -p")
		o.writeln("cmd_rmdir := rm -rf")
		o.writeln("cmd_copy  := cp -f")

	o.writeln("")

def gen_project(project):
	util.log("gen_project " + project.name)

	filename = bs.outdir + project.name + ".make"
	project.filename = filename

	o = util.OutBuffer()

	gen_common_var(o)

	if bs.cpp_objcpp:
		o.writeln("pch_header_compiler_language = objective-c++-header")
		o.writeln("cpp_source_compiler_language = objective-c++")
	else:
		o.writeln("pch_header_compiler_language = c++-header")
		o.writeln("cpp_source_compiler_language = c++")

	o.writeln("")

	phony = ["clean", "build", "run"]
	for config_name in project.configs:
		phony.append(config_name + "__build")
		phony.append(config_name + "__clean")
		phony.append(config_name + "__run")
	o.write(".PHONY: " + ''.join(['\\\n\t' + f for f in phony]) + '\n')

	o.writeln("all: build")
	o.writeln('')

	cpp_obj_files = OrderedDict()

	files = list(project.fileEntries)
	files.extend(project.generatedUniteFileEntries)

	for e in files:
		f = e.filename
		if not e.buildNeeded:
			continue
		if e.type == ".cpp":
			cpp_obj = e.basename +'_obj'
			if cpp_obj in cpp_obj_files:
				raise Exception("Error duplicated cpp filename " + f + ' \n ' + cpp_obj_files[cpp_obj])
			cpp_obj_files[cpp_obj] = f

	o.writeln('')

	for config_name, config in project.configs.items():
		o.newline()
		o.newline()
		o.writeln('#===== ' + config_name + ' ======================')
		o.writeln("#!!!")
		o.writeln('#!!! Make cannot handle file path contain space in variable')
		o.writeln('#!!! therefore we try to unroll all file dependenices directly in makefile instead of using make variable')
		o.writeln("#!!!")

		output_target   = config.output_target
		e_output_target = escape_str(output_target)
		intermediate_dir = util.absFilePath( bs.outdir + '/_build_tmp/' + config_name + '/' + project.name) + '/'
		cpp_obj_dir = intermediate_dir + "cpp_objs/"

		cpp_include_files = []
		#pch_include_dir = ""
		pch_cc_flags = ""

		o.writeln(config_name + '__build: ' + e_output_target)
		o.writeln('')

		o.writeln(config_name + '__clean:')
		o.writeln('\t$(cmd_rmdir) "' + intermediate_dir + '"')
		o.writeln('')

		#-----------

		o.writeln("#------- precompiler header ----------")
		pch_cc_flags = ''
		if project.pch_header:
			pch_header_src = util.addBaseDir(project.pch_header, project.build_file_dir)
			pch_header_pch = intermediate_dir + "cpp_pch/" + util.basename(project.pch_header, True) + pch_suffix
			pch_header_dep = pch_header_pch + '.d'

			e_pch_header_src = escape_str(pch_header_src)
			e_pch_header_pch = escape_str(pch_header_pch)
			e_pch_header_dep = escape_str(pch_header_dep)

			if bs.compiler=="gcc":
				pch_cc_flags   = '-I' + quote_str(util.dirname(pch_header_pch)) + ' -include ' + quote_str(util.basename(pch_header_src,True))
			else:
				pch_cc_flags   = '-include-pch "' + pch_header_pch + '"'

			o.writeln('#--- pch_header dependencies ------')
			o.writeln(e_pch_header_pch + ' : ' + e_pch_header_src)
			o.writeln('\t@echo "-------------------------------------------------------------"')
			o.writeln('\t@echo "[precompiler header] $< => $@"')
			o.writeln('\t$(cmd_mkdir) "'+ util.dirname(pch_header_pch) + '"')
			o.writeln('\t$(cmd_cc) -x $(pch_header_compiler_language) $(CPP_DEFINES) $(CPP_FLAGS) $(CPP_INCLUDE_DIRS) -o "$@" -c "' + pch_header_src + '" -MMD -MQ "$@" -MF "' + pch_header_dep + '"')
			o.writeln('-include ' + e_pch_header_dep)
			o.writeln('')

		o.writeln('')
		o.writeln("#------------")

		cpp_defines = ' '.join(['-D' + x for x in config.cpp_defines.final.keys()])
		cpp_flags   = ' '.join(config.cpp_flags.final.keys())
		link_flags  = ' '.join(config.link_flags.final.keys())		

		o.writeln(config_name + '__INTERMEDIATE_DIR  = ' + escape_str(intermediate_dir))
		if project.pch_header:
			o.writeln(config_name + '__PCH_HEADER_SRC    = ' + escape_str(pch_header_src))
			o.writeln(config_name + '__PCH_HEADER_PCH    = ' + escape_str(pch_header_pch))
			o.writeln(config_name + '__PCH_HEADER_DEP    = ' + escape_str(pch_header_pch) + ".d")	
			
		o.writeln(config_name + '__PCH_CC_FLAGS      = ' + pch_cc_flags)
		o.writeln(config_name + '__CPP_INCLUDE_DIRS  = ' + ' '.join(['\\\n\t -I' + quote_str(f) for f in config.include_dirs.final.keys()]))
		o.writeln(config_name + '__CPP_INCLUDE_FILES = ' + ' '.join(['-include ' + quote_str(f) for f in cpp_include_files]))
		o.writeln(config_name + '__CPP_FLAGS         = ' + cpp_flags )
		o.writeln(config_name + '__CPP_DEFINES       = ' + cpp_defines )		
		o.writeln(config_name + '__LINK_FLAGS        = ' + link_flags )
		o.writeln(config_name + '__LINK_FILES        = ' + ' '.join(['\\\n\t' + quote_str(f) for f in config.link_files.final.keys()]))
		o.writeln(config_name + '__CPP_OBJ_FILES     = ' + ' '.join(['\\\n\t' + quote_str(cpp_obj_dir + f) for f in cpp_obj_files]))

		o.writeln('')
		o.writeln('#--- ' + config_name + ' cpp_obj dependencies ------')
		o.writeln('')

		for cpp_obj, cpp in cpp_obj_files.items():
			cpp_obj = cpp_obj_dir + cpp_obj
			cpp_dep = cpp_obj + '.d'
			e_cpp_obj = escape_str(cpp_obj)
			e_cpp_dep = escape_str(cpp_dep)
			e_cpp_src = escape_str(cpp)

			if project.pch_header:
				o.writeln(e_cpp_obj + ' : ' + e_pch_header_pch)

			o.writeln(e_cpp_obj + ' : ' + e_cpp_src)
			o.writeln('\t@echo "-------------------------------------------------------------"')
			o.writeln('\t@echo "[compile cpp] => $@"')
			o.writeln('\t$(cmd_mkdir) "' + cpp_obj_dir + '"')
			o.writeln('\t$(cmd_cc) -x $(cpp_source_compiler_language) $(PCH_CC_FLAGS) $(CPP_DEFINES) $(CPP_FLAGS) $(CPP_INCLUDE_DIRS) $(CPP_INCLUDE_FILES) -o "$@" -c "'+ cpp +'" -MMD -MQ "$@" -MF "' + cpp_dep + '"')
			o.writeln('')
			o.writeln('-include ' + e_cpp_dep)
			o.writeln('')

		#-------------------------------
		o.writeln('')
		o.writeln('#----- ' + config_name + ' output target ----------')

		if project.type == "cpp_exe":
			o.writeln(e_output_target + ": $(LINK_FILES)")
			o.writeln('\t@echo "-------------------------------------------------------------"')
			o.writeln('\t@echo "[cpp_exe] $@"')
			o.writeln('\t$(cmd_mkdir) "' + util.dirname(output_target) + '"') #gmake cannot handle path contain 'space' in function $(@D)
			o.writeln('\t$(cmd_link) -o "$@" $(CPP_OBJ_FILES) $(LINK_FILES) $(LINK_FLAGS)')
			o.writeln('')
			o.writeln(config_name + '__run: ' + e_output_target)
			o.writeln('\t' + quote_str(output_target))
			o.writeln('')

		elif project.type == "cpp_lib":
			o.writeln(e_output_target + ":")
			o.writeln('\t@echo "-------------------------------------------------------------"')
			o.writeln('\t@echo "[cpp_lib] $@"')
			o.writeln('\t$(cmd_mkdir) "' + util.dirname(output_target) + '"') #gmake cannot handle path contain 'space' in function $(@D)
			o.writeln('\t$(cmd_ar) rcs "$@" $(CPP_OBJ_FILES)')
			o.writeln('')
			o.writeln('run_' + config_name + ': ' + e_output_target)
			o.writeln('\t @echo cannot run cpp_lib ' + quote_str(output_target))
			o.writeln('')
		else:
			raise Exception("unknown project.type " + project.type)

		o.writeln('#----- ' + config_name + ' output target dependencies ----------')
		o.writeln(e_output_target + ':\\')
		for cpp_obj, cpp in cpp_obj_files.items():
			o.writeln('\t' + escape_str(cpp_obj_dir + cpp_obj) + '\\' )
		for f in config.link_files.final.keys():
			o.writeln('\t' + escape_str(f) + '\\' )

	o.writeln('')
	o.writeln("#-----------")
	o.writeln('INTERMEDIATE_DIR   = $($(config)__INTERMEDIATE_DIR)')
	o.writeln('PCH_HEADER_SRC     = $($(config)__PCH_HEADER_SRC)')
	o.writeln('PCH_HEADER_PCH     = $($(config)__PCH_HEADER_PCH)')
	o.writeln('PCH_HEADER_DEP     = $($(config)__PCH_HEADER_DEP)')
	o.writeln('PCH_CC_FLAGS       = $($(config)__PCH_CC_FLAGS)')
	o.writeln('')
	o.writeln('CPP_INCLUDE_DIRS   = $($(config)__CPP_INCLUDE_DIRS)')
	o.writeln('CPP_INCLUDE_FILES  = $($(config)__CPP_INCLUDE_FILES)')
	o.writeln('CPP_FLAGS          = $($(config)__CPP_FLAGS)')
	o.writeln('CPP_DEFINES        = $($(config)__CPP_DEFINES)')
	o.writeln('LINK_FLAGS         = $($(config)__LINK_FLAGS)')
	o.writeln('LINK_FILES         = $($(config)__LINK_FILES)')
	o.writeln('CPP_OBJ_FILES      = $($(config)__CPP_OBJ_FILES)')
	o.writeln('')
	o.writeln("build: $(config)__build")
	o.writeln("clean: $(config)__clean")
	o.writeln("run:   $(config)__run")
	o.writeln('')

	util.writeFile(filename, o.getValue())

def gen_helper_batch_file():
	util.writeFile(bs.outdir + "mkdir.bat", '@ECHO OFF\n IF exist "%1" (echo directory "%1" exists) ELSE ( mkdir "%1" && echo directory "%1" created)')

def gen_workspace():
	util.log("gen_workspace " + bs.workspace_name)
	#workspace_name = bs.workspace_name + "_" + "_" + bs.platform
	filename = bs.outdir + "Makefile"

	gen_helper_batch_file()

	o = util.OutBuffer()

	gen_common_var(o)

	o.write(".PHONY: clean_all build run")
	for project in bs.projects.values():
		gen_project(project)
		o.write(" " + project.name)
	o.writeln("\n")

	o.writeln("all: build")
	o.writeln('')

	#o.writeln("build: " + bs.startup_project)
	o.writeln("build: " + ' '.join([escape_str(f) for f in bs.projects]))
	o.writeln('\t@echo "--- Finish ---"')
	o.writeln('')

	o.writeln("run: build ")
	o.writeln('\t@echo "=============================================================="')
	o.writeln('\t$(MAKE) -f ' + quote_str(bs.startup_project + '.make') + ' run $(.MAKEFLAGS)')

	o.writeln("clean_all:")
	o.writeln('\t@echo "=============================================================="')
	for project in bs.projects.values():
		o.writeln('\t$(MAKE) -f ' + quote_str(project.name + '.make') + ' clean $(.MAKEFLAGS)')
	o.writeln('\t@echo " "')
	o.writeln('')

	for project in bs.projects.values():
		o.writeln(escape_str(project.name) + ": " + ' '.join([escape_str(f) for f in project.dependencies]))
		o.writeln('\t@echo "=============================================================="')
		o.writeln('\t@echo "[build project] ' + project.name + ' "')
		o.writeln('\t$(MAKE) -f ' + quote_str(project.name + '.make') + ' build $(.MAKEFLAGS)')
		o.writeln('')

	util.writeFile(filename, o.getValue())

def generate():
	global make_multithread_flags
	if bs.multithread_build:
		make_multithread_flags = '-j'

	gen_workspace()

def build():
	cmd = ['make']
	if make_multithread_flags:
		cmd.append(make_multithread_flags)
	cmd.extend(['-C', bs.outdir, 'build'])
	util.shell_exec(cmd)

def run_target():
	cmd = ['make']
	if make_multithread_flags:
		cmd.append(make_multithread_flags)
	cmd.extend(['-C', bs.outdir, 'run'])
	util.shell_exec(cmd)

def init(buildSettings):
	global bs
	bs = buildSettings

	if bs.generator is None:
		bs.generator = "makefile"

	if bs.compiler is None:
		bs.compiler = "gcc"
		