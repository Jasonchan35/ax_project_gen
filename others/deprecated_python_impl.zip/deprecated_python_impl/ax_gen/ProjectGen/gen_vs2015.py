from ProjectGen import BuildSettings, util, FileEntry
from collections import OrderedDict
import xml.etree.ElementTree as ETree
import uuid

bs = None
output_cpu = ""
output_os = ""

header_file_exts = [".h", ".hpp", ".hxx"]
cpp_file_exts = [".c", ".cpp", ".cxx", ".cc"]

def genUuid():
	return str(uuid.uuid4()).upper()

def gen_vcxproj_filter_helper(rootDir, dirs, files):
	for e in files:
		f = e.filename
		f = util.windowsFilePath(f)
		rel = util.relFilePath(f, rootDir)
		d = util.dirname(rel)

		# extract all directory along the path
		dd = d
		while (dd):
			dd = util.windowsFilePath(dd)
			if not dd in dirs:
				dirs[dd] = []
			dd = util.dirname(dd)

		# add file to dirs dict
		d = util.windowsFilePath(d)
		if d in dirs:
			dirs[d].append(e)
		else:
			dirs[d] = [e]


def gen_vcxproj_filters_file(project, addedFiles, addedGenFiles):
	util.log("gen_vcxproj_filters " + project.name)
	filename = bs.outdir + project.name + ".vcxproj.filters"

	node_proj = ETree.Element("Project", attrib = {
		"ToolsVersion":"4.0",
		"xmlns":"http://schemas.microsoft.com/developer/msbuild/2003"
	})

	dirs = OrderedDict()
	gen_vcxproj_filter_helper(bs.outdir, dirs, addedGenFiles)
	gen_vcxproj_filter_helper(project.build_file_dir, dirs, addedFiles)

	# Filters
	node_item_group = ETree.SubElement(node_proj, "ItemGroup")
	for d in dirs:
		if len(d) > 0:
			ETree.SubElement(node_item_group, "Filter", attrib = {"Include":d})
			#node_filter = ETree.SubElement(node_item_group, "Filter", attrib = {"Include":d})
			#ETree.SubElement(node_filter, "UniqueIdentifier").text = "{" + str(uuid.uuid4()) + "}"

	#--------------------
	node_item_group = ETree.SubElement(node_proj, "ItemGroup")
	for d, dfiles in dirs.items():
		for e in dfiles:
			f = e.filename
			#f = util.windowsFilePath(f)
			if e.type == ".h":
				node_file = ETree.SubElement(node_item_group, "ClInclude", attrib = {"Include":f})
			elif e.type in [".cpp", ".c"]:
				node_file = ETree.SubElement(node_item_group, "ClCompile", attrib = {"Include":f})
			else:
				node_file = ETree.SubElement(node_item_group, "None", attrib = {"Include":f})
			#-----
			if len(d) > 0:
				ETree.SubElement(node_file, "Filter").text = d

	util.writeXmlFile(filename, node_proj)

def gen_linux_config_options(node_proj, config):
	config_cond = {"Condition":"'$(Configuration)|$(Platform)'=='" + config.name + "|" + output_cpu + "'"}
	node_prop_group = ETree.SubElement(node_proj, "PropertyGroup", attrib = config_cond)	

	if config.name == "Debug":
		ETree.SubElement(node_prop_group, "UseDebugLibraries").text = "true"
	else:
		ETree.SubElement(node_prop_group, "UseDebugLibraries").text = "false"


def gen_config_options(node_proj, config):
	project = config.project
	config_cond = {"Condition":"'$(Configuration)|$(Platform)'=='" + config.name + "|" + output_cpu + "'"}
	node_prop_group = ETree.SubElement(node_proj, "PropertyGroup", attrib = config_cond)

	ETree.SubElement(node_prop_group, "IntDir").text     = "_build_tmp/$(Configuration)/$(ProjectName)/"
	ETree.SubElement(node_prop_group, "OutDir").text     = config.output_dir + '/'
	ETree.SubElement(node_prop_group, "TargetName").text = util.basename(config.output_target, False)
	ETree.SubElement(node_prop_group, "TargetExt").text  = util.fileExt(config.output_target)

	node_g = ETree.SubElement(node_proj, "ItemDefinitionGroup", attrib = config_cond)
	node_cl = ETree.SubElement(node_g, "ClCompile")
	ETree.SubElement(node_cl, "Optimization").text = "Disabled"
	ETree.SubElement(node_cl, "PreprocessorDefinitions").text = "%(PreprocessorDefinitions)"
	ETree.SubElement(node_cl, "SDLCheck").text = "true"
	ETree.SubElement(node_cl, "DebugInformationFormat").text = "ProgramDatabase"

	mt_build = 'false'
	if bs.multithread_build:
		mt_build = 'true'

	ETree.SubElement(node_cl, "MultiProcessorCompilation").text = mt_build

	if config.name == "Debug":
		ETree.SubElement(node_cl, "MinimalRebuild").text = "true"
		ETree.SubElement(node_cl, "Optimization").text = "Disabled"
		ETree.SubElement(node_cl, "RuntimeLibrary").text = "MultiThreadedDebugDLL"
	else:
		ETree.SubElement(node_cl, "MinimalRebuild").text = "false"
		ETree.SubElement(node_cl, "WholeProgramOptimization").text = "true"
		ETree.SubElement(node_cl, "Optimization").text = "MaxSpeed"
		ETree.SubElement(node_cl, "RuntimeLibrary").text = "MultiThreadedDLL"
		ETree.SubElement(node_cl, "FunctionLevelLinking").text = "true"
		ETree.SubElement(node_cl, "IntrinsicFunctions").text = "true"
		ETree.SubElement(node_cl, "WholeProgramOptimization").text = "true"
		ETree.SubElement(node_cl, "BasicRuntimeChecks").text = "Default"

	if project.pch_header is not None:
		#pch_header = util.basename(config.pch_header, True)
		ETree.SubElement(node_cl, "PrecompiledHeader").text = "Use"
		ETree.SubElement(node_cl, "PrecompiledHeaderFile").text = project.pch_header
		ETree.SubElement(node_cl, "ForcedIncludeFiles").text    = project.pch_header

	if config.warning_level is not None:
		ETree.SubElement(node_cl, "WarningLevel").text = config.warning_level
	
	ETree.SubElement(node_cl, "TreatWarningAsError").text = 'true' if config.warning_as_error else 'false'

	def addOption(parentNode, name, item):
		ETree.SubElement(parentNode, name).text = ";".join(item.keys()) + ";%(" + name + ")"
		
	addOption(node_cl, "DisableSpecificWarnings", 		config.disable_warning.final)
	addOption(node_cl, "PreprocessorDefinitions", 		config.cpp_defines.final)
	addOption(node_cl, "AdditionalIncludeDirectories", 	config.include_dirs.final)

	# --- Link ---
	node_link = ETree.SubElement(node_g, "Link")
	ETree.SubElement(node_link, "SubSystem").text = "Console"
	ETree.SubElement(node_link, "GenerateDebugInformation").text = "true"

	if project.type == "cpp_exe" or project.type == "cpp_dll":
		addOption(node_link, "AdditionalLibraryDirectories", 	config.link_dirs.final)		
		addOption(node_link, "AdditionalDependencies", 			config.link_files.final)

	if config.name == "Debug":
		pass
	else:
		ETree.SubElement(node_link, "EnableCOMDATFolding").text = "true"
		ETree.SubElement(node_link, "OptimizeReferences").text = "true"

	#-------
	#kernel32.lib;user32.lib;gdi32.lib;winspool.lib;comdlg32.lib;advapi32.lib;shell32.lib;ole32.lib;oleaut32.lib;uuid.lib;odbc32.lib;odbccp32.lib;%(AdditionalDependencies)

	#OUTPUT_TARGET
	''''
	if project.type == "cpp_exe":
		ETree.SubElement(node_link, "OutputFile").text = util.windowsFilePath(config.output_target)
	elif project.type == "cpp_lib":
		node_lib = ETree.SubElement(node_g, "Lib")
		ETree.SubElement(node_lib, "OutputFile").text = util.windowsFilePath(config.output_target)
	'''

def gen_project(project):
	util.log("gen_project " + project.name)

	filename = bs.outdir + project.name + ".vcxproj"

	node_proj = ETree.Element("Project", attrib = {
		"DefaultTargets":"Build",
		"ToolsVersion":"12.0",
		"xmlns":"http://schemas.microsoft.com/developer/msbuild/2003"
	})
	node_item_group = ETree.SubElement(node_proj, "ItemGroup", attrib = {
		"Label":"ProjectConfigurations"
	})

	for config_name, config in project.configs.items():
		node_proj_config = ETree.SubElement(node_item_group, "ProjectConfiguration", attrib = {
			"Include":(config_name + "|" + output_cpu)
		})
		node_config   = ETree.SubElement(node_proj_config, "Configuration")
		node_platform = ETree.SubElement(node_proj_config, "Platform")
		node_config.text = config_name
		node_platform.text = output_cpu

	node_prop_group = ETree.SubElement(node_proj, "PropertyGroup", attrib = {
		"Label":"Globals"
	})

	ETree.SubElement(node_prop_group, "ProjectGuid").text = "{" + project.uuid + "}"
	ETree.SubElement(node_prop_group, "Keyword").text = "Win32Proj"
	ETree.SubElement(node_prop_group, "RootNamespace").text = project.name

	if bs.generator == "vs2015_linux":
		ETree.SubElement(node_prop_group, "ApplicationType").text = "Linux"
		ETree.SubElement(node_prop_group, "ApplicationTypeRevision").text = "1.0"
		ETree.SubElement(node_prop_group, "TargetLinuxPlatform").text = "Generic"
		ETree.SubElement(node_prop_group, "LinuxProjectType").text = "{D51BCBC9-82E9-4017-911E-C93873C4EA2B}"		
	else:
		ETree.SubElement(node_prop_group, "WindowsTargetPlatformVersion").text = "8.1"

	# source file group
	node_item_group = ETree.SubElement(node_proj, "ItemGroup")
	addedFiles = []
	addedGenFiles = []

	# add pch.cpp
	if project.pch_header and bs.compiler == "msvc" :
		pch_cpp = util.absFilePath(project.generatedDir + project.name + "-precompiledHeader.cpp")
		#pch_cpp = util.windowsFilePath(pch_cpp)
		pch_code =  '//-- Auto Generated File for Visual C++ precompiled header\n'
		pch_code += '#include "{}"\n\n'.format(project.pch_header)
		util.writeFile(pch_cpp, pch_code)
		node_cl = ETree.SubElement(node_item_group, "ClCompile", attrib = {"Include":pch_cpp})
		ETree.SubElement(node_cl, "PrecompiledHeader").text = "Create"
		addedGenFiles.append(FileEntry.FileEntry(project, pch_cpp))

	#------- unite build files -------
	for e in project.generatedUniteFileEntries:
		f = e.filename
		#f = util.windowsFilePath(f)
		addedGenFiles.append(e)
		node_cl = ETree.SubElement(node_item_group, "ClCompile", attrib = {"Include":f})

	#--------------
	for e in project.fileEntries:
		f = e.filename
		#f = util.windowsFilePath(f)
		addedFiles.append(e)		
		#basename = util.basename(f, True)
		if e.type == ".h":
			ETree.SubElement(node_item_group, "ClInclude", attrib = {"Include":f})
		elif e.type in [".cpp", ".c"]:
			node_file = ETree.SubElement(node_item_group, "ClCompile", attrib = {"Include":f})
			if project.unite_build:
				ETree.SubElement(node_file, "ExcludedFromBuild").text = "true"
		else:
			ETree.SubElement(node_item_group, "None", attrib = {"Include":f})

	#==========
	ETree.SubElement(node_proj, "Import", attrib = {
		"Project":"$(VCTargetsPath)\\Microsoft.Cpp.Default.props"
	})
	node_prop_group = ETree.SubElement(node_proj, "PropertyGroup", attrib = {
		"Label":"Configuration"
	})

	if project.type == "cpp_lib":
		ETree.SubElement(node_prop_group, "ConfigurationType").text = "StaticLibrary"
	elif project.type == "cpp_exe":
		ETree.SubElement(node_prop_group, "ConfigurationType").text = "Application"
	else:
		raise Exception("Unknown project type " + project.type)

	ETree.SubElement(node_prop_group, "UseDebugLibraries").text = "true"
	ETree.SubElement(node_prop_group, "CharacterSet").text = "Unicode"

	if bs.generator == "vs2015_linux":
		ETree.SubElement(node_prop_group, "PlatformToolset").text = "Remote_GCC_1_0"
	else:
		ETree.SubElement(node_prop_group, "PlatformToolset").text = "v140_xp"		

	#========
	ETree.SubElement(node_proj, "Import", attrib = {"Project":"$(VCTargetsPath)\\Microsoft.Cpp.props"})

	if bs.generator == "vs2015_linux":
		ETree.SubElement(node_proj, "ImportGroup", attrib = {"Label":"ExtensionSettings"})
		ETree.SubElement(node_proj, "ImportGroup", attrib = {"Label":"Shared"})
	

	#==========
	node_import_group = ETree.SubElement(node_proj, "ImportGroup", attrib = {"Label":"PropertySheets"})

	if bs.generator == "":
		ETree.SubElement(node_import_group, "Import", attrib = {
			"Project":"$(UserRootDir)\\Microsoft.Cpp.$(Platform).user.props",
			"Condition":"exists('$(UserRootDir)\\Microsoft.Cpp.$(Platform).user.props')",
			"Label":"LocalAppDataPlatform"
		})

	#==========
	node_prop_group = ETree.SubElement(node_proj, "PropertyGroup", attrib = {"Label":"UserMacros"})

	#==========
	for config in project.configs.values():
		if bs.generator == "vs2015_linux":
			gen_linux_config_options(node_proj, config)
		else:
			gen_config_options(node_proj, config)

	ETree.SubElement(node_proj, "Import", attrib = {"Project":"$(VCTargetsPath)\\Microsoft.Cpp.targets"})
	node_import_group = ETree.SubElement(node_proj, "ImportGroup", attrib = {"Label":"ExtensionTargets"})

	util.writeXmlFile(filename, node_proj)
	gen_vcxproj_filters_file(project, addedFiles, addedGenFiles)

def gen_workspace_add_project(outBuffer, project):
	o = outBuffer
	o.writeln('Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "' + project.name + '", "' + project.name + '.vcxproj", "{'+ project.uuid +'}"')
	if project.type == "cpp_exe" or project.type == "cpp_dll":
		if len(project.dependencies) > 0:
			o.writeln('\tProjectSection(ProjectDependencies) = postProject')
			for dep_proj in project.dependencies.values():
				o.writeln("\t\t{" + dep_proj.uuid + "} = {" + dep_proj.uuid + "}")
			o.writeln('\tEndProjectSection')
	o.writeln('EndProject')

def gen_workspace_project_categories(outBuffer):
	o = outBuffer
	for c in bs.project_categories:
		o.writeln('Project("{2150E333-8FDC-42A3-9474-1A3956D46DE8}") = "' + c.name + '", "' + c.name + '", "{'+ c.uuid +'}"')
		o.writeln('EndProject')

	o.writeln('Global')
	o.writeln('\tGlobalSection(NestedProjects) = preSolution')

	for parent in bs.project_categories:
		for c in parent.children.values():
			o.writeln('\t\t{' + c.uuid + '} = {' + parent.uuid + '}')
		for c in parent.projects:
			o.writeln('\t\t{' + c.uuid + '} = {' + parent.uuid + '}')
			
	o.writeln('\tEndGlobalSection')
	o.writeln('EndGlobal')
	

def get_cache_uuid(projects_uuid, obj, key):
	if key in projects_uuid:
		prev_uuid = projects_uuid[key]
		obj.uuid = prev_uuid
	else:
		obj.uuid = genUuid()
		projects_uuid[key] = obj.uuid	

def gen_workspace():
	util.log("gen_workspace " + bs.workspace_name)
	workspace_name = bs.workspace_name # + "_" + bs.platform
	filename = bs.outdir + workspace_name + ".sln"
	cache_filename = bs.outdir + "/ax_build_cache.json"

	o = util.OutBuffer()
	o.writeln("")
	o.writeln('Microsoft Visual Studio Solution File, Format Version 12.00')
	o.writeln('# Visual Studio 14')
	o.writeln('VisualStudioVersion = 14.0.25420.1')
	o.writeln('MinimumVisualStudioVersion = 10.0.40219.1')

	cache = OrderedDict()

	if util.fileExists(cache_filename):
		cache = util.readJsonFile(cache_filename)

	if "projects_uuid" not in cache:
		cache["projects_uuid"] = OrderedDict()

	projects_cache_uuid = cache["projects_uuid"]

	#-------
	for c in bs.project_categories:
		get_cache_uuid(projects_cache_uuid, c, c.fullpath)
			
	#-------
	for k, project in bs.projects.items():
		get_cache_uuid(projects_cache_uuid, project, k)
		gen_project(project)

	startup_project = None
	
	if bs.startup_project != "":
		if not bs.startup_project in bs.projects:
			raise Exception("Cannot find startup project " + bs.startup_project)
		startup_project = bs.projects[bs.startup_project]
		util.log(">===== startup_project = " + startup_project.name)


	#put the startup project the first project, then it will be come startup project when no .suo file
	if startup_project is not None:
		gen_workspace_add_project(o, startup_project)		
		
	for k, project in bs.projects.items():
		if startup_project is project:
			continue
		gen_workspace_add_project(o, project)

	gen_workspace_project_categories(o)

	util.writeFile(filename, o.getValue())
	util.writeJsonFile(cache_filename, cache)

def generate():
	global output_cpu
	#global output_os
	#global workspaceType

	if bs.cpu == "x86":
		output_cpu = "Win32"
	elif bs.cpu == "x86_64":
		output_cpu = "x64"
	else:
		raise Exception("Unsupport cpu type " + bs.cpu)

	gen_workspace()

def openIde():
	workspace_name = bs.workspace_name # + "_" + bs.platform
	filename = bs.outdir + workspace_name + ".sln"	
	print("open visual studio solution: " + filename)
	util.shell_run(filename)

def init(buildSettings):
	global bs
	bs = buildSettings

	if bs.generator is None:
		bs.generator = "vs2015"

	if bs.compiler is None:
		bs.compiler = "msvc"
		