import sys
import platform
import ProjectGen
from ProjectGen import util
from ProjectGen import *

util.log("====================================================")
util.log("args = [" + ",\n   ".join(sys.argv))
util.log("]\n------------")

bs = ProjectGen.BuildSettings.BuildSettings()

def detect_os(v):
	if v == "cygwin" or v.startswith("CYGWIN"):
		return "cygwin"
	if v == "Windows":
		return "windows"
	if v == "linux" or v == "Linux":
		return "linux"
	if v == "FreeBSD":
		return "freebsd"
	if v == "Darwin" or v == "Mac" or v == "macosx":
		return "macosx"
	if v == "iOS":
		return "ios"
	raise Exception("Unknown os " + v)

def detect_cpu(v):
	if v == "x86_64" or v == "AMD64" or v == "amd64":
		return "x86_64"
	if v == "x86"  or v == "i686":
		return "x86"
	raise Exception("Unknown cpu " + v)

def detect_compiler(v):
	return v

bs.host_os	= detect_os(  platform.system()  )
bs.host_cpu	= detect_cpu( platform.machine() )

bs.os		= bs.host_os
bs.cpu		= bs.host_cpu

#-----------------
def print_help(msg):
	o = msg + "\n"
	o += "run.py <ws=example.axworkspace> <gen=??> <compiler=??> <os=??> <cpu=??> <-gen> <-build> <-run> <-open> \n"
	o += "\n"
	o += "gen=\n"
	o += "    vs2015 - Visual Studio 2015 \n"
	o += "  makefile - Makefile support GNUmake(gmake), BSD make (bmake) \n"
	o += "     xcode - Xcode \n"
	o += "\n"
	o += "compiler=\n"
	o += "      msvc - Microsoft Visual C++ \n"
	o += "       gcc - GNU C++ \n"
	o += "     clang - LLVM Clang \n"
	o += "\n"
	o += "os=\n"
	o += "   windows - Microsoft Windows \n"
	o += "     linux - Linux   \n"
	o += "   freebsd - FreeBSD \n"
	o += "    macosx - MacOSX  \n"
	o += "    cygwin - Cygwin  \n"
	o += "\n"
	o += "cpu=\n"
	o += "       x86 - Intel x86 \n"
	o += "    x86_64 - Intel x86 64 bit \n"
	o += "       arm - ARM \n"
	o += "\n"
	o += "command:\n"
	o += "  -gen   - generate projects\n"
	o += "  -build - build project\n"
	o += "  -run   - run product (startup project)\n"
	o += "  -open  - Open IDE \n"
	o += "\n"
	o += "------------\n"
	raise Exception(o)

call_gen	= False
call_clean	= False
call_build	= False
call_run	= False
call_open	= False

bs.workspace_file = ""
bs.generator = ""

if len(sys.argv) == 1:
	print_help("")

#---- read from argv -------------
for i in range(1, len(sys.argv)):
	a = sys.argv[i]
	#print(">>>>>>>>> '" + a + "'")

	arg_workspace = util.getStringFromPrefix(a, "ws=")
	if len(arg_workspace):
		bs.workspace_file = util.absFilePath(arg_workspace)
		continue

	arg_generator = util.getStringFromPrefix(a, "gen=")
	if len(arg_generator):
		bs.generator = arg_generator
		continue

	arg_cpu = util.getStringFromPrefix(a, "cpu=")
	if len(arg_cpu):
		bs.cpu = detect_cpu( arg_cpu )
		continue

	arg_os = util.getStringFromPrefix(a, "os=")
	if len(arg_os):
		bs.os = detect_os( arg_os )
		continue

	arg_compiler = util.getStringFromPrefix(a, "compiler=")
	if len(arg_compiler):
		bs.compiler = detect_compiler( arg_compiler )
		continue

	if a == "-gen":
		call_gen = True
		continue

	if a == "-build":
		call_build = True
		continue

	if a == "-clean":
		call_clean = False
		continue

	if a == "-run":
		call_run = True
		continue

	if a == "-open":
		call_open = True
		continue

#--------------
if bs.os == "macosx" or bs.os == "ios":
	bs.cpp_objcpp = True

#--------------
if bs.generator == "vs2015":
	gen = ProjectGen.gen_vs2015
elif bs.generator == "vs2015_linux":
	gen = ProjectGen.gen_vs2015_linux
elif bs.generator == "xcode":
	gen = ProjectGen.gen_xcode
elif bs.generator == "makefile":
	gen = ProjectGen.gen_makefile
elif bs.generator == "monodevelop":
	gen = ProjectGen.gen_monodevelop
elif bs.generator == "codeblock":
	gen = ProjectGen.gen_codeblock
else:
	print_help("Unknown generator " + bs.generator)

#-----------------
gen.init(bs)

#-----------------
bs.platform = bs.generator + "-" + bs.compiler + "-" + bs.os + "-" + bs.cpu
bs.outdir = util.absFilePath( util.dirname(bs.workspace_file) + "/_local_build/" + bs.platform ) + "/"

util.openLogFile(util.absFilePath(bs.outdir) + "/_projectGen.log")
util.log("")
util.log("workspace = " + bs.workspace_file)
util.log("gen       = " + bs.generator)
util.log("os        = " + bs.os)
util.log("compiler  = " + bs.compiler)
util.log("cpu       = " + bs.cpu)
util.log("platform  = " + bs.platform)
#util.log("")
#util.log("host_os   = " + bs.host_os)
#util.log("host_cpu  = " + bs.host_cpu)
#util.log("")
util.log("outdir    = " + bs.outdir)

if call_gen:
	util.log('\n---- Start generate --------------------')
	util.log("default_config = " + bs.default_config)	
	bs.readMasterFile( bs.workspace_file )
	bs.resolve()
	#debug dump
	bs.dump()
	gen.generate()
	util.log('----- End generate -------------------')

if call_clean:
	util.log('\n---- Start clean --------------------')
	gen.clean()
	util.log('----- End clean -------------------')

if call_build:
	util.log('\n---- Start build --------------------')
	gen.build()
	util.log('----- End build -------------------')

if call_run:
	util.log('\n---- call_run --------------------')
	gen.run_target()
	util.log('----- End call_run -------------------')

if call_open:
	util.log('\n---- call_openIde --------------------')
	gen.openIde()
	util.log('----- End call_openIde -------------------')
	
util.closeLogFile()